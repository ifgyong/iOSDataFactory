
//
//  ThreeView.m
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import "ThreeView.h"
#import "DotLabel.h"
@implementation ThreeView

-(id)initWithFrame:(CGRect)frame{
    self =[super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor greenColor];
//        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5.0f;
        
        DotLabel *dotLabel = [DotLabel new];
        dotLabel.userInteractionEnabled = YES;
        dotLabel.textAlignment = NSTextAlignmentCenter;
        dotLabel.frame = CGRectMake(-15, -15, 30, 30);
        dotLabel.textColor =[UIColor whiteColor];
        dotLabel.text = @"3";
        [self addSubview:dotLabel];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapSelect)];
        [self addGestureRecognizer:tap];
    }
    return self;
}
-(void)tapSelect{
    if (_delegate && [_delegate respondsToSelector:@selector(changeViewFrame:)]) {
        [_delegate changeViewFrame:self];
    }
}
@end

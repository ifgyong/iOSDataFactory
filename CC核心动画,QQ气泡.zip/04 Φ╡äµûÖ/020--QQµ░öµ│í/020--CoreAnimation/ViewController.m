//
//  ViewController.m
//  020--CoreAnimation
//
//  Created by CC老师 on 2019/1/7.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import "ViewController.h"
/*
 拆分动画:
 1.2个圆(一个固定圆,一个拖拽圆) (完成!)
 2.贝塞尔曲线,求得关键点 (完成!)
 3.固定圆的比例缩小
 4.拖拽到一定距离则需要断开
 5.断开之后有一个反弹的动画效果
 */


@interface ViewController ()
//圆1
@property (nonatomic, strong) UIView *view1;
//圆2
@property (nonatomic, strong) UIView *view2;
//shapeLayer图层
@property (nonatomic, strong) CAShapeLayer *shapeLayer;

//坐标记录
@property (nonatomic, assign) CGPoint oldViewCenter;
@property (nonatomic, assign) CGRect oldViewFrame;
@property (nonatomic, assign) CGFloat r1;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //1.UI.
    [self setUp];
}

-(void)setUp
{
    //1.view1
    _view1 = [[UIView alloc]initWithFrame:CGRectMake(36, CGRectGetHeight(self.view.bounds)-66, 40, 40)];
    _view1.layer.cornerRadius = 20;
    _view1.backgroundColor = [UIColor redColor];
    [self.view addSubview:_view1];
    
    //2.view2
    _view2 = [[UIView alloc]initWithFrame:CGRectMake(36, CGRectGetHeight(self.view.bounds)-66, 40, 40)];
    _view2.layer.cornerRadius = 20;
    _view2.backgroundColor = [UIColor redColor];
    [self.view addSubview:_view2];
    
    //3.提示数
    UILabel *label = [[UILabel alloc]initWithFrame:_view2.bounds];
    label.text = @"99";
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor];
    [_view2 addSubview:label];
    
    
    //4.添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    [_view2 addGestureRecognizer:pan];
    

    
    
}

-(void)panAction:(UIPanGestureRecognizer *)pan{
    
  
    
}

-(void)caculPoint{
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

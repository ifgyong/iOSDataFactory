//
//  ViewController.m
//  XMHDragView
//
//  Created by Ed on 15/16/11.
//  Copyright © 2015年 Ed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


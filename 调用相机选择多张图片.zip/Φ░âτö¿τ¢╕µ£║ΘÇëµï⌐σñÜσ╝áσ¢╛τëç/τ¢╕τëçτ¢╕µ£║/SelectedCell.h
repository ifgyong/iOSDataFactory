//
//  SelectedCell.h
//  相片相机
//
//  Created by ZJF on 16/6/3.
//  Copyright © 2016年 ZJF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectedCell : UICollectionViewCell


@property (nonatomic,strong)UIImageView * iv;



@end

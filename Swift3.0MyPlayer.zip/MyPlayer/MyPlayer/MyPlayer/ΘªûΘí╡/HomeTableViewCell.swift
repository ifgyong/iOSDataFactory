//
//  HomeTableViewCell.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var imageBgView: UIView!
    
    @IBOutlet weak var publisherLabel: UILabel!
    var _imageList:Array<String>?;
    var imageList:Array<String>{
        set{
            _imageList = newValue;
            creatImageView();
        }
        get{
            return _imageList!;
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
       
        creatImageView();
    }
    
    func creatImageView(){
        for view1 in imageBgView.subviews{
            view1.removeFromSuperview();
        }
        if _imageList == nil{
            return;
        }
        var count = _imageList?.count;
        if count! > 3 {
            count = 3;
        }
        
        for i:Int in 0..<count! {
            let spece = 10;
            let imageV = UIImageView.init(frame: CGRect.init(x: CGFloat(spece) + CGFloat(i) * ((kScreenWidth-40)/3 + CGFloat(spece)), y: 0, width: (kScreenWidth-40)/3, height: 80));
            imageV.sd_setImage(with: URL.init(string: (_imageList?[i])!));
            imageV.contentMode = UIViewContentMode.scaleAspectFit;
            imageBgView.addSubview(imageV);
        }
    }

    
}

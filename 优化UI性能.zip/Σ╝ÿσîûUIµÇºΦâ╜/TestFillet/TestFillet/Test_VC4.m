//
//  Test_VC4.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/29.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC4.h"

@interface Test_VC4 ()<UITableViewDelegate,UITableViewDataSource>


@end

@implementation Test_VC4

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
}


#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 600;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        
        UILabel *Label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 44)];
        Label.tag = 991;
        Label.text = @"真爱是存在的吗";
        Label.backgroundColor = [UIColor whiteColor];
        Label.clipsToBounds=YES;
        [cell.contentView addSubview:Label];
        
        UIImage *iamge = [UIImage imageNamed:@"lena.png"];
        
        UIImageView *imageV = [[UIImageView alloc]initWithImage:[self CGContextClip:iamge cornerRadius:512/2]];
        imageV.frame = CGRectMake(180, 0, 60, 44);
        [cell.contentView addSubview:imageV];
        
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(260, 0, 44, 44)];
        button.backgroundColor = [UIColor whiteColor];
        [button setImage:[self CGContextClip:iamge cornerRadius:512/2] forState:UIControlStateNormal];
        button.layer.masksToBounds = YES;
        [cell.contentView addSubview:button];
        
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(320, 0, 60, 44)];
        view.layer.contents = (__bridge id _Nullable)([self CGContextClip:iamge cornerRadius:512/2].CGImage);
        //        view.backgroundColor = [UIColor whiteColor];
        view.clipsToBounds=YES;
        [cell.contentView addSubview:view];
        
    }
    return cell;
}


// CGContext 裁剪
- (UIImage *)CGContextClip:(UIImage *)img cornerRadius:(CGFloat)c {
    int w = img.size.width * img.scale;
    int h = img.size.height * img.scale;
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(w, h), true, 1.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    ///首先为了不让其有像素混合的问题,先把背景绘制出来
    CGContextSetFillColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextFillRect(context, CGRectMake(0, 0, w, h));
    CGContextDrawPath(context, kCGPathFillStroke); //根据坐标绘制路径
    
    CGContextMoveToPoint(context, 0, c);
    CGContextAddArcToPoint(context, 0, 0, c, 0, c);
    CGContextAddLineToPoint(context, w-c, 0);
    CGContextAddArcToPoint(context, w, 0, w, c, c);
    CGContextAddLineToPoint(context, w, h-c);
    CGContextAddArcToPoint(context, w, h, w-c, h, c);
    CGContextAddLineToPoint(context, c, h);
    CGContextAddArcToPoint(context, 0, h, 0, h-c, c);
    CGContextAddLineToPoint(context, 0, c);
    CGContextClosePath(context);
    
    CGContextClip(context);     // 先裁剪 context，再画图，就会在裁剪后的 path 中画
    [img drawInRect:CGRectMake(0, 0, w, h)];       // 画图
    CGContextDrawPath(context, kCGPathFill);
    
    UIImage *ret = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return ret;
}

@end

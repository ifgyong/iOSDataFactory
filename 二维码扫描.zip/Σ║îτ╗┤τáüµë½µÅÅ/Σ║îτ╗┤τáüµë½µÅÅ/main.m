//
//  main.m
//  二维码扫描
//
//  Created by feique on 16/9/12.
//  Copyright © 2016年 com.feique. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}


extern int base1();
extern int base2();

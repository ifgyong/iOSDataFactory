//
//  BaseTabBarController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
        
    }
    
    class func changeKeyWindowRootViewController(){
        
        let homeNav = BaseNavigationController.init(rootViewController:HomeViewController.init());
        let hearNav = BaseNavigationController.init(rootViewController:HeartViewController.init());
        let myNav = BaseNavigationController.init(rootViewController:MyViewController.init());
        
        homeNav.title = "首页";
        hearNav.title = "心情";
        myNav.title = "我的";
        homeNav.tabBarItem.image = UIImage.init(named:"分类");
        homeNav.tabBarItem.selectedImage = UIImage.init(named: "分类on")
        hearNav.tabBarItem.image = UIImage.init(named:"专题");
        hearNav.tabBarItem.selectedImage = UIImage.init(named: "专题on")
        myNav.tabBarItem.image = UIImage.init(named:"精选");
        myNav.tabBarItem.selectedImage = UIImage.init(named: "精选on")
        let tabBarController = BaseTabBarController.init();
        tabBarController.viewControllers = [homeNav,hearNav,myNav];
        UIApplication.shared.keyWindow?.rootViewController = tabBarController;
        tabBarController.tabBar.tintColor = UIColor.orange;
        
    }
   
    
}

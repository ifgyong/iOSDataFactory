//
//  MyViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class MyViewController: BaseViewController ,UITableViewDelegate,UITableViewDataSource{
    var _tableView:UITableView?;
    var headView:MyTableHeaderView?;
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的";
        self.view.backgroundColor = UIColor.white;
        self.automaticallyAdjustsScrollViewInsets = false;
        _tableView = UITableView.init(frame: CGRect.init(x: 0, y: 64, width: kScreenWidth, height: kScreenHeight-64-49));
        _tableView?.delegate = self;
        _tableView?.dataSource = self;
        _tableView?.tableFooterView = UIView.init();
        self.view.addSubview(_tableView!);
        headView = Bundle.main.loadNibNamed("MyTableHeaderView", owner: nil, options: nil)?.last as! MyTableHeaderView?;
        _tableView?.tableHeaderView = headView as UIView?;
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated);
        let user = BmobUser.current();
        if user?.username != nil {
            headView?.nameLabel.text = user?.username;
        }else{
            headView?.nameLabel.text = "昵称";
        }
        
        if user?.object(forKey: "imageUrl") != nil {
            headView?.imageV.sd_setImage(with: URL.init(string: user?.object(forKey: "imageUrl") as! String));
        }else{
            headView?.imageV.image = UIImage.init(named: "psb-3.jpeg");
        }
        if user?.object(forKey: "desc") != nil {
            headView?.infoLabel.text = user?.object(forKey: "desc") as! String?;
        }else{
            headView?.infoLabel.text = "xxxxxxxxx";
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "myCell");
        if cell == nil {
            
            cell = UITableViewCell.init(style: UITableViewCellStyle.default, reuseIdentifier: "myCell");
        }
        
        let titleArr:Array<String> = ["发布记忆","发表心情","已发布的记忆","已发表的心情","修改个人信息","关于我们","打赏开发者"];
        cell?.textLabel?.text = titleArr[indexPath.row];
        cell?.accessoryType = UITableViewCellAccessoryType.disclosureIndicator;
        return cell!;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true);
        let user = BmobUser.current();
        if user == nil  {
            self.showAlerController(title: "您还未登陆", message: "请点击上方图片进入登录");
            return;
        }
        if indexPath.row == 0 {
            let viewC = PJViewController.init(nibName:"PJViewController", bundle:nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 1 {
            let viewC = PHeartViewController.init(nibName:"PHeartViewController", bundle:nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 2 {
            let viewC = HistoryJYViewController.init();
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 3 {
            let viewC = HistoryHeartViewController.init();
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 4 {
            let viewC = PersoninfoViewController.init(nibName:"PersoninfoViewController", bundle:nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 5 {
            let viewC = AboutUsViewController.init(nibName:"AboutUsViewController", bundle:nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }else if indexPath.row == 6 {
            let viewC = AwardViewController.init(nibName:"AwardViewController", bundle:nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.navigationController?.pushViewController(viewC, animated: true);
        }
        
        
    }

  
    
}

//
//  dotLabel.m
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import "DotLabel.h"

@implementation DotLabel

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor redColor];
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 15.0f;
    }
    return self;
}

@end

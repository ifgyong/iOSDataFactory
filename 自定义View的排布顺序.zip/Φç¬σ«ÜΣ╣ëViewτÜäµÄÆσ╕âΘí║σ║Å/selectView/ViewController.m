//
//  ViewController.m
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import "ViewController.h"
#import "OneView.h"
#import "TwoView.h"
#import "ThreeView.h"
@interface ViewController ()<OneViewDelegate,TwoViewDelegate,ThreeViewDelegate>{
    OneView *oneView;
    TwoView *twoView;
    ThreeView *threeView;
}

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor =[UIColor whiteColor];
    
    oneView = [OneView new];
    oneView.delegate = self;
    oneView.frame = CGRectMake(40, 100, self.view.frame.size.width - 80, self.view.frame.size.width- 40);
    [self.view addSubview:oneView];
    
    twoView = [TwoView new];
    twoView.delegate = self;
    twoView.frame = CGRectMake(30, 130, self.view.frame.size.width - 60, self.view.frame.size.width- 40);
    [self.view addSubview:twoView];
    
    
    threeView = [ThreeView new];
    threeView.delegate = self;
    threeView.frame = CGRectMake(20, 160, self.view.frame.size.width - 40, self.view.frame.size.width - 40);
    [self.view addSubview:threeView];
    
    
}
-(void)changeViewFrame:(UIView *)view{
    if ([view isKindOfClass:[OneView class]]) {
        [UIView animateWithDuration:0.3 animations:^{
           oneView.frame = CGRectMake(20, 160, self.view.frame.size.width - 40, self.view.frame.size.width- 40);
            twoView.frame = CGRectMake(30, 130, self.view.frame.size.width - 60, self.view.frame.size.width- 40);
            threeView.frame = CGRectMake(40, 100, self.view.frame.size.width - 80, self.view.frame.size.width - 40);
            [self.view addSubview:threeView];
            [self.view addSubview:twoView];
            [self.view addSubview:oneView];
        }];
    }else if ([view isKindOfClass:[TwoView class]]){
        [UIView animateWithDuration:.3 animations:^{
            oneView.frame = CGRectMake(30, 130, self.view.frame.size.width - 60, self.view.frame.size.width- 40);
            twoView.frame = CGRectMake(20, 160, self.view.frame.size.width - 40, self.view.frame.size.width- 40);
            threeView.frame = CGRectMake(40, 100, self.view.frame.size.width - 80, self.view.frame.size.width - 40);
            [self.view addSubview:threeView];
            [self.view addSubview:oneView];
            [self.view addSubview:twoView];
        }];
        
    }else if ([view isKindOfClass:[ThreeView class]]){
        [UIView animateWithDuration:.3 animations:^{
            oneView.frame = CGRectMake(30, 130, self.view.frame.size.width - 60, self.view.frame.size.width- 40);
            twoView.frame = CGRectMake(40, 100, self.view.frame.size.width - 80, self.view.frame.size.width- 40);
            threeView.frame = CGRectMake(20, 160, self.view.frame.size.width - 40, self.view.frame.size.width - 40);
            [self.view addSubview:twoView];
            [self.view addSubview:oneView];
            [self.view addSubview:threeView];
        }];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  HistoryJYTableViewCell.swift
//  MyPlayer
//
//  Created by ybon on 2016/10/31.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HistoryJYTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBOutlet weak var bgimageView: UIView!
    
    @IBOutlet weak var publisherLabel: UILabel!
    
    
    @IBOutlet weak var delBtn: UIButton!
    var objectId:String?;
    //闭包定义为属性的格式
    var delFuncation :  (()->Void)?;
    
    var _imageList:Array<String>?;
    var imageList:Array<String>{
        set{
            _imageList = newValue;
            creatImageView();
        }
        get{
            return _imageList!;
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        delBtn.layer.cornerRadius = 5;
        delBtn.layer.masksToBounds = true;
        delBtn.layer.borderWidth = 1;
        delBtn.layer.borderColor = UIColor.lightGray.cgColor;
        
    }
    
    func creatImageView(){
        for view1 in bgimageView.subviews{
            view1.removeFromSuperview();
        }
        if _imageList == nil{
            return;
        }
        var count = _imageList?.count;
        if count! > 3 {
            count = 3;
        }
        
        for i:Int in 0..<count! {
            let spece = 10;
            let imageV = UIImageView.init(frame: CGRect.init(x: CGFloat(spece) + CGFloat(i) * ((kScreenWidth-40)/3 + CGFloat(spece)), y: 0, width: (kScreenWidth-40)/3, height: 80));
            imageV.sd_setImage(with: URL.init(string: (_imageList?[i])!));
            imageV.contentMode = UIViewContentMode.scaleAspectFit;
            bgimageView.addSubview(imageV);
        }
    }
    @IBAction func delBtnAction(_ sender: UIButton) {
        
        
        let gamescore:BmobObject = BmobObject(outDataWithClassName: "HomeList", objectId: objectId)
        gamescore.deleteInBackground { (isSuccessful, error) in
            if self.delFuncation != nil{
                self.delFuncation!();
 
            }
            
        }
        
        
    }
    
   
    
}

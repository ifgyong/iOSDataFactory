//
//  ViewController.m
//  相片相机
//
//  Created by ZJF on 16/5/31.
//  Copyright © 2016年 ZJF. All rights reserved.
//

#import "ViewController.h"
#import "postPicViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btn:(UIButton *)sender {
    
    
    postPicViewController * p = [[postPicViewController alloc]init];
    
    
    [self.navigationController pushViewController:p animated:NO];
    
    
}
@end

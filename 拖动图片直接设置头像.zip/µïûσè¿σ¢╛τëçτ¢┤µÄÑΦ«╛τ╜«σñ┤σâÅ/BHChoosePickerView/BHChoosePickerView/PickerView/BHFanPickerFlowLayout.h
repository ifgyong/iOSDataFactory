//
//  BHFanPickerFlowLayout
//
//  Created by libohao on 15/6/24.
//
//

#import <UIKit/UIKit.h>

@interface BHFanPickerFlowLayout : UICollectionViewFlowLayout

+ (instancetype)PickerFlowLayout;

@property (nonatomic, assign) CGFloat zoomFactor;

@end

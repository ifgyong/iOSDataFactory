//
//  HomeInfoCollectionView.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HomeInfoCollectionView: UICollectionView ,UICollectionViewDelegate,UICollectionViewDataSource{
    var _imageList:Array<String>?;
    var imageList:Array<String>{
        set{
            _imageList = newValue;
            self.reloadData();
        }
        get{
            return _imageList!;
        }
    }
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout);
        self.delegate = self;
        self.dataSource = self;
        self.isPagingEnabled = true;
        self.register(UINib.init(nibName: "HomeinfoCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "infoCell");
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if _imageList == nil {
            return 0;
        }
        return _imageList!.count;
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "infoCell", for: indexPath) as! HomeinfoCollectionViewCell;
        cell.imageV.sd_setImage(with: URL.init(string: (_imageList?[indexPath.row])!));
        return cell;
    }
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let ce = cell as! HomeinfoCollectionViewCell;
        ce.bringScrollView();
    }
}

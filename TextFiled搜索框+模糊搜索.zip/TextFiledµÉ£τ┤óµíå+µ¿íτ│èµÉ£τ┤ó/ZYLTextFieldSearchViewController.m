//
//  ZYLTextFieldSearchViewController.m
//  ZYLTextFieldSearch
//
//  Created by zhuyuelong on 16/7/4.
//  Copyright © 2016年 zhuyuelong. All rights reserved.
//

#import "ZYLTextFieldSearchViewController.h"

@interface ZYLTextFieldSearchViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>



@end

@implementation ZYLTextFieldSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.dataArr = [[NSMutableArray alloc] initWithObjects:@"辽宁",@"沈阳",@"浑南",@"大东",@"铁西",@"辽宁l",@"沈阳s",@"浑南h",@"大东d",@"铁西t", nil];
    
    self.resultArr = [NSMutableArray array];
    
    
    
    [self createTextFileAndTableView];
    
    
}

-(void)createTextFileAndTableView{
    

    
    
    self.search = [[UITextField alloc] initWithFrame:CGRectMake(50, 100, 200, 30)];
    
    self.search.borderStyle = UITextBorderStyleLine;
    
    self.search.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    self.search.delegate = self;
    
    [self.view addSubview:self.search];
    
    [self.search addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    

    
    self.tableView  = [[UITableView alloc] initWithFrame:CGRectMake(self.search.frame.origin.x, self.search.frame.origin.y + self.search.frame.size.height + 3, self.search.frame.size.width, 200) style:UITableViewStylePlain];
    
    self.tableView.hidden = YES;
    
    self.tableView.delegate = self;
    
    self.tableView.dataSource = self;
    
    self.tableView.showsVerticalScrollIndicator = NO;
    
    [self.view addSubview:self.tableView];
    
    self.resultTableView  = [[UITableView alloc] initWithFrame:CGRectMake(self.search.frame.origin.x, self.search.frame.origin.y + self.search.frame.size.height + 3, self.search.frame.size.width, 200) style:UITableViewStylePlain];
    
    self.resultTableView.hidden = YES;
    
    self.resultTableView.delegate = self;
    
    self.resultTableView.dataSource = self;
    
    self.resultTableView.showsVerticalScrollIndicator = NO;
    
    [self.view addSubview:self.resultTableView];
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if (tableView != self.tableView) {
        
        return self.resultArr.count;
    
    }
    
    return self.dataArr.count;

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"textcell"];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"textcell"];
        
    }
    
    if (tableView != self.tableView) {
        
        cell.textLabel.text = self.resultArr[indexPath.row];
        
    }else{
    
        cell.textLabel.text = self.dataArr[indexPath.row];
        
    }
    
    return cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    self.search.text = self.dataArr[indexPath.row];
    
    self.tableView.hidden = YES;
    
    self.resultTableView.hidden = YES;

}

- (void) textFieldDidChange:(UITextField *) TextField{


    [self textFileSearch:TextField.text];
    

}

-(void)textFileSearch:(NSString *)TextField{


    if (TextField == nil || [TextField isEqualToString:@""]) {
        
        self.tableView.hidden = NO;
        
        self.resultTableView.hidden = YES;
        
        [self.tableView reloadData];
        
    }else{
        
        self.resultTableView.hidden = NO;
        
    }
    
    //    // 完成具体的搜索功能
    //    // 1.清空搜索结果数组
    [self.resultArr removeAllObjects];
    
    int k = 0;
    
    //2。通过循环数据，找出与搜索关键字匹配的内容，把匹配的内容添加到数组中
    
    for (NSString *str in self.dataArr) {
        
        NSString *ste = [NSString stringWithFormat:@"%@",str];
        
        NSRange range = [ste rangeOfString:TextField];
        
        if (range.length) {
            
            [self.resultArr addObject:self.dataArr[k]];
            
        }
        
        k++;
        
        //                [self.tableView reloadData];
        
        [self.resultTableView reloadData];
        
    }
    

}


//当用户全部清空的时候的时候 会调用
-(BOOL)textFieldShouldClear:(UITextField *)textField{

    self.tableView.hidden = NO;
    
    self.resultTableView.hidden = YES;
    
    [self.tableView reloadData];
    
    return YES;
    
}

//可以得到用户输入的字符
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
      return YES;
    
}

//已经开始编辑的时候 会触发这个方法
- (void)textFieldDidBeginEditing:(UITextField *)textField{

    if (self.text != nil) {
        
        [self textFileSearch:self.text];
        
    }
    
    self.tableView.hidden = NO;
    
}

//结束编辑的时候调用

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    self.text = textField.text;
    
    self.tableView.hidden = YES;
    
    self.resultTableView.hidden = YES;


}

//点击Return键的时候，（标志着编辑已经结束了）

-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    return YES;

}

#pragma mark - UITextFieldDelegate
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [self.search resignFirstResponder];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

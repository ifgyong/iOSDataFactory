//
//  Model.h
//  test
//
//  Created by mac on 20/1/6.
//  Copyright © 2020年 shinefee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject
@property(nonatomic)NSString *word;
@end

//
//  AppDelegate.h
//  相片相机
//
//  Created by ZJF on 16/5/31.
//  Copyright © 2016年 ZJF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


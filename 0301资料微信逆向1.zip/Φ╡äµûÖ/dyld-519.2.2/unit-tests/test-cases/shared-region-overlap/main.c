#include <stdlib.h> // EXIT_SUCCESS

#include "test.h"


int
main()
{
	return EXIT_SUCCESS;
}



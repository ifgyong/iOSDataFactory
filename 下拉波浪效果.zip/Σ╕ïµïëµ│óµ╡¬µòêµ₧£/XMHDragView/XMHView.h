//
//  XMHView.h
//  XMHDragView
//
//  Created by Ed on 15/12/31.
//  Copyright © 2015年 Ed. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface XMHView : UIView

@end

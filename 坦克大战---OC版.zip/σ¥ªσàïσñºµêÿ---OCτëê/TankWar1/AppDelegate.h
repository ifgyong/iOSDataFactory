//
//  AppDelegate.h
//  TankWar1
//
//  Created by yq on 15/9/18.
//  Copyright © 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  ImagePickItem.h
//  图片选取Demo
//
//  Created by Mac on 15-11-2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>


#define kDeleteButtonTagBass 200
#define kSpace  10
#define kImageWidth  ([UIScreen mainScreen].bounds.size.width-40)/3
#define kImageHight  (([UIScreen mainScreen].bounds.size.width-40)/3 + 20)

@interface ImagePickItem : UIImageView

@property (nonatomic,assign)int index;

@property (nonatomic,strong)UIButton *deleteButton;


@end

//
//  ViewController.m
//  组合动画
//
//  Created by JiaFuyang on 15/12/14.
//  Copyright © 2015年 JiaFuyang. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface ViewController ()
{
    UIButton *btn1;
    UIButton *btn2;
    UIButton *btn3;
    UIButton *btn4;
    UIButton *btn5;
    UIButton *btn6;
    UIButton *btn7;
    UIButton *btn8;
    UIButton *btn9;
    UIButton *btn10;
    NSTimer *timer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    float x = 20;
    
    btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1 = [[UIButton alloc] init];
    btn1.userInteractionEnabled = YES;
    btn1.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn1 setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [btn1 setTitle:@"说故事" forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    btn1.frame = CGRectMake(10, 85, x+20, x+5);
    btn1.backgroundColor = [UIColor redColor];
    
    btn8 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn8 = [[UIButton alloc] init];
    btn8.userInteractionEnabled = YES;
    
    [btn8 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn8 setTitle:@"失恋" forState:UIControlStateNormal];
    btn8.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn8 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn8];
    btn8.frame = CGRectMake(85, 50, 15+ x,  x+3);
    btn8.backgroundColor = [UIColor yellowColor];
    
    btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2 = [[UIButton alloc] init];
    [btn2 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn2.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn2 setTitle:@"无聊" forState:UIControlStateNormal];
    btn2.userInteractionEnabled = YES;
    [btn2 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    btn2.frame = CGRectMake(70, 130, x+25, x+8);
    btn2.backgroundColor = [UIColor yellowColor];
   
    
    btn9 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn9 = [[UIButton alloc] init];
    btn9.userInteractionEnabled = YES;
    btn9.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn9 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn9 setTitle:@"伤感" forState:UIControlStateNormal];
    [btn9 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn9];
    btn9.frame = CGRectMake(120, 110, 20+ x, 8+ x);
    btn9.backgroundColor = [UIColor greenColor];
    
    btn7 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn7 = [[UIButton alloc] init];
    btn7.userInteractionEnabled = YES;
    [btn7 setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    btn7.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn7 setTitle:@"生气" forState:UIControlStateNormal];
    [btn5 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn7];
    btn7.frame = CGRectMake(170, 30,  13+ x, x-5);
    btn7.backgroundColor = [UIColor orangeColor];
   
    btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn3 = [[UIButton alloc] init];
    btn3.userInteractionEnabled = YES;
    [btn3 setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [btn3 setTitle:@"惊讶" forState:UIControlStateNormal];
    btn3.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn3 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn3];
    btn3.frame = CGRectMake(160, 150, x+30, x+10);
    btn3.backgroundColor = [UIColor blueColor];
    
    btn10 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn10 = [[UIButton alloc] init];
    btn10.userInteractionEnabled = YES;
    btn10.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn10 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn10 setTitle:@"厌恶" forState:UIControlStateNormal];
    [btn10 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn10];
    btn10.frame = CGRectMake(210, 60, 5+x, 5+ x);
    btn10.backgroundColor = [UIColor purpleColor];

    btn6 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn6 = [[UIButton alloc] init];
    btn6.userInteractionEnabled = YES;
    btn6.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn6 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn6 setTitle:@"开心" forState:UIControlStateNormal];
    [btn6 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn6];
    btn6.frame = CGRectMake(260, 45,  15+ x, 3 + x);
    btn6.backgroundColor = [UIColor yellowColor];


    btn4 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn4 = [[UIButton alloc] init];
    btn4.userInteractionEnabled = YES;
    btn4.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn4 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn4 setTitle:@"幸福" forState:UIControlStateNormal];
    [btn4 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn4];
    btn4.frame = CGRectMake(250, 120, 25+ x, 8+ x);
    btn4.backgroundColor = [UIColor yellowColor];
    
    btn5 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn5 = [[UIButton alloc] init];
    btn5.userInteractionEnabled = YES;
    btn5.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn5 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn5 setTitle:@"迷茫" forState:UIControlStateNormal];
    [btn5 addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn5];
    btn5.frame = CGRectMake(330, 70, 15+ x, x+3);
    btn5.backgroundColor = [UIColor purpleColor];
    
    

    
    [self performSelector:@selector(donghuaAction) withObject:self afterDelay:0.0];

}

-(void)donghuaAction
{
    //1.创建核心动画
    CAKeyframeAnimation *keyAnima1=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima2=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima3=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima4=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima5=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima6=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima7=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima8=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima9=[CAKeyframeAnimation animation];
    CAKeyframeAnimation *keyAnima10=[CAKeyframeAnimation animation];
    
    
    //平移
    keyAnima1.keyPath=@"position";
    keyAnima2.keyPath=@"position";
    keyAnima3.keyPath=@"position";
    keyAnima4.keyPath=@"position";
    keyAnima5.keyPath=@"position";
    keyAnima6.keyPath=@"position";
    keyAnima7.keyPath=@"position";
    keyAnima8.keyPath=@"position";
    keyAnima9.keyPath=@"position";
    keyAnima10.keyPath=@"position";
    
//    keyAnima1.keyPath=@"transform";
//    btn1.transform = CGAffineTransformMakeScale(2, 2);
    //1.1告诉系统要执行什么动画
    NSValue *value1=[NSValue valueWithCGPoint:CGPointMake(50, 100)];//失恋
    NSValue *value2=[NSValue valueWithCGPoint:CGPointMake(80, 150)];//说故事
    NSValue *value3=[NSValue valueWithCGPoint:CGPointMake(180, 170)];//无聊
    NSValue *value4=[NSValue valueWithCGPoint:CGPointMake(280, 130)];//惊讶
    NSValue *value5=[NSValue valueWithCGPoint:CGPointMake(340, 80)]; //幸福
    NSValue *value6=[NSValue valueWithCGPoint:CGPointMake(260, 50)]; // 迷茫
    NSValue *value7=[NSValue valueWithCGPoint:CGPointMake(180,40)]; // 开心
    NSValue *value8=[NSValue valueWithCGPoint:CGPointMake(100, 60)]; // 生气
    
    NSValue *value9=[NSValue valueWithCGPoint:CGPointMake(190, 110)]; // 伤感
    NSValue *value10=[NSValue valueWithCGPoint:CGPointMake(220, 70)];
    NSValue *value11=[NSValue valueWithCGPoint:CGPointMake(170, 80)];
    NSValue *value12=[NSValue valueWithCGPoint:CGPointMake(130, 120)];
//    NSValue *value10=[NSValue valueWithCGPoint:CGPointMake(400, 100)];
    keyAnima1.values=@[value1,value2,value3,value4,value5,value6,value7,value8,value1];
    keyAnima2.values=@[value2,value3,value4,value5,value6,value7,value8,value1,value2];
    keyAnima3.values=@[value3,value4,value5,value6,value7,value8,value1,value2,value3];
    keyAnima4.values=@[value4,value5,value6,value7,value8,value1,value2,value3,value4];
    keyAnima5.values=@[value5,value6,value7,value8,value1,value2,value3,value4,value5];
    keyAnima6.values=@[value6,value7,value8,value1,value2,value3,value4,value5,value6];
    keyAnima7.values=@[value7,value8,value1,value2,value3,value4,value5,value6,value7];
    keyAnima8.values=@[value8,value1,value2,value3,value4,value5,value6,value7,value8];
    keyAnima9.values=@[value9,value10,value11,value12,value9];
    keyAnima10.values=@[value11,value12,value9,value10,value11];
//    keyAnima8.values=@[value1,value2,value3,value4,value5,value6,value7,value8,value1];
//    keyAnima9.values=@[value1,value2,value3,value4,value5,value6,value7,value8,value1];
//    keyAnima10.values=@[value1,value2,value3,value4,value5,value6,value7,value8,value1];
    //1.2设置动画执行完毕后，不删除动画
    keyAnima1.removedOnCompletion=NO;
    //1.3设置保存动画的最新状态
    keyAnima1.fillMode=kCAFillModeForwards;
    //1.4设置动画执行的时间
    keyAnima1.duration=15.0;
    keyAnima1.repeatCount = MAXFLOAT;
    //1.5设置动画的节奏
    keyAnima1.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
    //设置代理，开始—结束
    keyAnima1.delegate=self;
    
    keyAnima2.removedOnCompletion=NO;
    keyAnima2.fillMode=kCAFillModeForwards;
    keyAnima2.duration=15.0;
    keyAnima2.repeatCount = MAXFLOAT;
    keyAnima2.delegate=self;
    keyAnima2.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
    keyAnima3.removedOnCompletion=NO;
    keyAnima3.fillMode=kCAFillModeForwards;
    keyAnima3.duration=15.0;
    keyAnima3.repeatCount = MAXFLOAT;
    keyAnima3.delegate=self;
    keyAnima3.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
    keyAnima4.removedOnCompletion=NO;
    keyAnima4.fillMode=kCAFillModeForwards;
    keyAnima4.duration=15.0;
    keyAnima4.repeatCount = MAXFLOAT;
    keyAnima4.delegate=self;
    keyAnima4.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];

    keyAnima5.removedOnCompletion=NO;
    keyAnima5.fillMode=kCAFillModeForwards;
    keyAnima5.duration=15.0;
    keyAnima5.repeatCount = MAXFLOAT;
    keyAnima5.delegate=self;
    keyAnima5.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];

    keyAnima6.removedOnCompletion=NO;
    keyAnima6.fillMode=kCAFillModeForwards;
    keyAnima6.duration=15.0;
    keyAnima6.repeatCount = MAXFLOAT;
    keyAnima6.delegate=self;
    keyAnima6.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];

    keyAnima7.removedOnCompletion=NO;
    keyAnima7.fillMode=kCAFillModeForwards;
    keyAnima7.duration=15.0;
    keyAnima7.repeatCount = MAXFLOAT;
    keyAnima7.delegate=self;
    keyAnima7.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];

    keyAnima8.removedOnCompletion=NO;
    keyAnima8.fillMode=kCAFillModeForwards;
    keyAnima8.duration=15.0;
    keyAnima8.repeatCount = MAXFLOAT;
    keyAnima8.delegate=self;
    keyAnima8.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];

    keyAnima9.removedOnCompletion=NO;
    keyAnima9.fillMode=kCAFillModeForwards;
    keyAnima9.duration=5.0;
    keyAnima9.repeatCount = MAXFLOAT;
    keyAnima9.delegate=self;
    keyAnima9.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
    keyAnima10.removedOnCompletion=NO;
    keyAnima10.fillMode=kCAFillModeForwards;
    keyAnima10.duration=5.0;
    keyAnima10.repeatCount = MAXFLOAT;
    keyAnima10.delegate=self;
    keyAnima10.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
//    
//    btn1.transform=CGAffineTransformMakeScale(4.0 / 3, 4.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(9.0 / 3, 4.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(9.0 / 3, 4.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(10.0 / 3, 4.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(2.0 / 3, 4.0 / 3);
//    btn2.transform=CGAffineTransformMakeScale(4.0 / 3, 3.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(4.0 / 3, 4.0 / 3);
//    btn1.transform=CGAffineTransformMakeScale(4.0 / 3, 5.0 / 3);
    
    

//    //2.添加核心动画
    [btn1.layer addAnimation:keyAnima1 forKey:nil];
    [btn2.layer addAnimation:keyAnima2 forKey:nil];
    [btn3.layer addAnimation:keyAnima3 forKey:nil];
    [btn4.layer addAnimation:keyAnima4 forKey:nil];
    [btn5.layer addAnimation:keyAnima5 forKey:nil];
    [btn6.layer addAnimation:keyAnima6 forKey:nil];
    [btn7.layer addAnimation:keyAnima7 forKey:nil];
    [btn8.layer addAnimation:keyAnima8 forKey:nil];
    [btn9.layer addAnimation:keyAnima9 forKey:nil];
    [btn10.layer addAnimation:keyAnima10 forKey:nil];

}

-(void)btnAction:(UIButton *)sender
{
    NSLog(@"你好啊");
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  main.m
//  CaiDanTest
//
//  Created by peng on 16/8/4.
//  Copyright © 2016年 XT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

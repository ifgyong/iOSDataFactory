//
//  DMHeartFlyView.h
//  DMHeartFlyAnimation
//
//  Created by Rick on 16/3/9.
//  Copyright © 2016年 Rick. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DMHeartFlyView : UIView
-(void)animateInView:(UIView *)view;
@end


//
//  MainViewController.m
//  ZYLTextFieldSearch
//
//  Created by zhuyuelong on 16/7/4.
//  Copyright © 2016年 zhuyuelong. All rights reserved.
//

#import "ZYLMainViewController.h"
#import "ZYLTextFieldSearchViewController.h"
@interface ZYLMainViewController ()

@property (strong, nonatomic) UITextField *zylSearch;

@end

@implementation ZYLMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    self.zylSearch = [[UITextField alloc] initWithFrame:CGRectMake(50, 100, 200, 30)];
//    
//    [self.view addSubview:self.zylSearch];
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

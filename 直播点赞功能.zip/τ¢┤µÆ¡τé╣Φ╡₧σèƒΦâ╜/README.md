# DMHeartFlyAnimation
仿在直播、映客、Periscope、花椒等直播APP点赞动画
============================

这个是翻译成Objective-C<br>

swift版：https://github.com/singer1026/FloatingHearts<br>
原版地址：https://github.com/saidmarouf/FloatingHearts <br>
![效果图](/demo.gif)
//
//  HomeinfoCollectionViewCell.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HomeinfoCollectionViewCell: UICollectionViewCell ,UIScrollViewDelegate{

    @IBOutlet weak var scrollV: UIScrollView!
    @IBOutlet weak var imageV: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        scrollV.delegate = self;
        scrollV.minimumZoomScale = 1;
        scrollV.maximumZoomScale = 5;
        let longGest = UILongPressGestureRecognizer.init(target: self, action: #selector(SaveImage));
        imageV.addGestureRecognizer(longGest);
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageV;
    }
    func bringScrollView(){
        scrollV.setZoomScale(1, animated: true);
    }

    func SaveImage(){
        let alertC = UIAlertController.init(title: "是否保存图片", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet);
        let carmaAction = UIAlertAction.init(title: "保存", style: UIAlertActionStyle.default) { (UIAlertActiono) in
            
            UIImageWriteToSavedPhotosAlbum(self.imageV.image!, self, nil, nil);
        }
        let cancelAction = UIAlertAction.init(title: "取消", style: UIAlertActionStyle.cancel, handler: nil);
        
        alertC.addAction(carmaAction);
        alertC.addAction(cancelAction);
        self.viewController().present(alertC, animated: true, completion: nil);
        
    }
    
    
    
    
}

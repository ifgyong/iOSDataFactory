//
//  Test_VC.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/28.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC.h"

@interface Test_VC ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation Test_VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
    
//    http://www.jianshu.com/p/f970872fdc22
}
#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 600;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        ///UILabel的圆角产生离屏渲染,但是不会像素混合
        UILabel *Label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 44)];
        Label.tag = 991;
        Label.text = @"真爱是存在的吗";
        Label.backgroundColor = [UIColor whiteColor];
        [cell.contentView addSubview:Label];
        Label.layer.cornerRadius = 22;
        Label.layer.masksToBounds = YES;
        ///UIImageView的圆角不产生离屏渲染,但是会像素混合
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake(180, 0, 60, 44)];
        imageV.image = [UIImage imageNamed:@"lena.png"];
        [cell.contentView addSubview:imageV];
        imageV.layer.cornerRadius = 22;
        imageV.layer.masksToBounds = YES;
        ///UIButton的圆角产生离屏渲染,但是不会像素混合
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(260, 0, 44, 44)];
        button.backgroundColor = [UIColor whiteColor];
        button.layer.cornerRadius = 22;
        button.layer.masksToBounds = YES;
        [button setImage:[UIImage imageNamed:@"lena.png"] forState:UIControlStateNormal];
        [cell.contentView addSubview:button];
        ///UIView的圆角产生离屏渲染,但是不会像素混合,但是没有masksToBounds就会像素混合
        UIView *view = [[UILabel alloc]initWithFrame:CGRectMake(320, 0, 60, 44)];
        view.layer.cornerRadius = 22;
        view.layer.masksToBounds = YES;
        view.backgroundColor = [UIColor purpleColor];
        [cell.contentView addSubview:view];
        
    }
    
    return cell;
}


// UIBezierPath 裁剪
- (UIImage *)UIBezierPathClip:(UIImage *)img cornerRadius:(CGFloat)c {
    int w = img.size.width * img.scale;
    int h = img.size.height * img.scale;
    CGRect rect = CGRectMake(0, 0, w, h);
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(w, h), false, 1.0);
    [[UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:c] addClip];
    [img drawInRect:rect];
    UIImage *ret = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return ret;
}

@end





var age: Int? = 10
print(age)

print("my age is \(String(describing: age))")

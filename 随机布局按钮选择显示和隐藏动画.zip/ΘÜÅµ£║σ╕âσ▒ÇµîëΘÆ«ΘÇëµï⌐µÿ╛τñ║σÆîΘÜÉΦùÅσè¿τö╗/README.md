# ChooseWordView
选择字母验证单词是否正确的作业题型  
1、字母按钮随机布局  
2、显示动画、隐藏动画  
3、检测拼接是否正确  
示例：  
![示例图片](https://github.com/pxhmeiyangyang/ChooseWordView/blob/master/myyView.gif)    
如果可以请star一下，您的支持是我进步的最大动力   

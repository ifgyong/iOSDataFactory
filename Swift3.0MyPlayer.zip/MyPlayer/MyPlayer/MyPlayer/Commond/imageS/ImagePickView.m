//
//  ImagePickView.m
//  图片选取Demo
//
//  Created by Mac on 15-11-2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import "ImagePickView.h"
#import "UIView+UIViewController.h"
#import "GetPhotLibaryImage.h"
@implementation ImagePickView

{
    UIButton *addbutton;
    //item的旧的位置
    int oldIndex;
    //item的新的位置
    int currentIndex;
    
}

- (id)initWithFrame:(CGRect)frame withMaxCount:(NSInteger)maxCount{
    
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, kImageWidth*3 +kSpace *4, kImageHight*3 +kSpace*4);
        _maxImageCount = maxCount;
        _newlibary = [PHPhotoLibrary sharedPhotoLibrary];
        [self creatButton];
        
        _imageLiast = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)creatButton{
    
    addbutton=[UIButton buttonWithType:UIButtonTypeCustom];
    [addbutton setImage:[UIImage imageNamed:@"btn_add_photo_s"] forState:UIControlStateNormal];
    [addbutton setImage:[UIImage imageNamed:@"btn_add_photo_n"] forState:UIControlStateHighlighted];
    
//    addbutton.backgroundColor = [UIColor orangeColor];
    
    addbutton.frame = CGRectMake(10, 5, kImageWidth, kImageHight);
    [self addSubview:addbutton];
    [addbutton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
}

#pragma mark 选择图片按钮
- (void)buttonAction:(UIButton *)button{
    UIAlertController *viewC = [UIAlertController alertControllerWithTitle:@"选择图片来源" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *carma = [UIAlertAction actionWithTitle:@"相机" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self carmaPhoto];
    }];
    UIAlertAction *photoLibary = [UIAlertAction actionWithTitle:@"图库" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self photoLibaray];
        
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [viewC addAction:carma];
    [viewC addAction:photoLibary];
    [viewC addAction:cancel];
    [self.viewController presentViewController:viewC animated:YES completion:nil];
}
#pragma mark 相机
- (void)carmaPhoto{
   if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
       return;
   }
    UIImagePickerController *pick = [[UIImagePickerController alloc] init];
    pick.delegate = self;
    pick.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self.viewController presentViewController:pick animated:YES completion:nil];
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{

    

    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        [picker dismissViewControllerAnimated:YES completion:^{
        }];
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        [_imageLiast addObject:image];
        self.imageLiast = [NSMutableArray arrayWithArray:self.imageLiast];
        
    }
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark 照片库
- (void)photoLibaray{
    ZYImageCollectionViewController *imageView = [[ZYImageCollectionViewController alloc] initWithCollectionViewLayout:[[UICollectionViewLayout alloc] init]];
    
    imageView.delegate = self;
    
    if (_imageLiast>0) {
        if (_maxImageCount - _imageLiast.count <= 0) {
            
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"图片已到达上限" message:[NSString stringWithFormat:@"最多%ld张",_maxImageCount] preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
            [alertC addAction:action];
            [self.viewController presentViewController:alertC animated:YES completion:nil];
            return;
            
        }
        imageView.maxImageCount = _maxImageCount-_imageLiast.count;
        
    }
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:imageView];
    
    [self.viewController presentViewController:nav animated:YES completion:nil];
}
#pragma mark ImagePickerControllerDelegate
- (void)imagePickerSelected:(NSArray *)assetUrls{

    
    for (PHAsset *asset in assetUrls) {
        [self sgetImageWithAsset:asset Block:^(UIImage *image, NSDictionary *inf0) {
            
            [_imageLiast addObject:image];
            if (_imageLiast.count >= assetUrls.count) {
                self.imageLiast = [NSMutableArray arrayWithArray:_imageLiast];
                return ;
            }
            
        }];
        
    }
    
    
    
}

- (void)setImageLiast:(NSMutableArray *)imageLiast{
    
    for (UIView *item in self.subviews) {
        if ([item isKindOfClass:[ImagePickItem class]]) {
            
             [item removeFromSuperview];
        }
       
    }
    
    _imageLiast = imageLiast;
 
    _itemList = [[NSMutableArray alloc] init];
    
    int index = 0;
    
    for (UIImage *image in _imageLiast) {
        
        ImagePickItem *item = [[ImagePickItem alloc] initWithFrame:[self getItemRect:index]];
        
        item.backgroundColor = [UIColor purpleColor];
        item.index = index;
        
        [item.deleteButton addTarget:self action:@selector(itemDeleteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [_itemList addObject:item];
        [self addSubview:item];
        
//        [GetPhotLibaryImage getImageWithAsset:aset Block:^(UIImage *image, NSDictionary *inf0) {
//            
            item.image = image;
//        }];
        
        
        index++;
    }
   
    //更改添加图片按钮得位置
    addbutton.frame = [self getItemRect:(int)_itemList.count];
    if (_itemList.count >= _maxImageCount) {
        
        addbutton.hidden = YES;
    }
    
}

- (void)itemDeleteButtonAction:(UIButton *)button{
    
    NSInteger index = button.tag - kDeleteButtonTagBass;
    
    //从父视图上移除item
    ImagePickItem *item = _itemList[index];
    [item removeFromSuperview];
    
    //从item数组中移除
    [_itemList removeObjectAtIndex:index];
    //删除url数组中得url
    [_imageLiast removeObjectAtIndex:index];
    
    //刷新布局
    [self refreshView];
    
}

//从新布局
- (void)refreshView{
    
    int index = 0;

    for (ImagePickItem *item in _itemList) {
        
        [UIView animateWithDuration:.35 animations:^{
            
            item.frame = [self getItemRect:index];
            
            item.index = index;
            
        }];
        
        index ++;
    }
 
    [UIView animateWithDuration:.35 animations:^{
        
        //添加按钮重新布局
        addbutton.frame = [self getItemRect:(int)_itemList.count];
        if (_itemList.count < _maxImageCount) {
            
            addbutton.hidden = NO;
        }
        
    }];
   
    
}


- (CGRect)getItemRect:(int)index{
    
    CGFloat x = 10+index%3*kImageWidth + index%3*kSpace;
    CGFloat y = 5+index/3*kImageHight + index/3*kSpace;
    
    CGRect frame = CGRectMake(x, y, kImageWidth, kImageHight);
    
    return frame;
}

//通过点计算index
- (int)contentsPoint:(CGPoint)point{
 

    for(int index = 0;index < _itemList.count;index++){
        
        CGRect frame = [self getItemRect:index];
        
//        判断坐标是否在某一个frame内
                if (CGRectContainsPoint(frame, point)) {
        
                    return index;
                }

        
    }
    
    return 999;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint p1 = [touch locationInView:self];
    
    oldIndex = [self contentsPoint:p1];

    currentIndex = oldIndex;
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint p1 = [touch locationInView:self];
    
    int newIndex = [self contentsPoint:p1];
    
    
    if (newIndex == 999) {
        
        return;
    }
    
    if (newIndex != currentIndex) {
        
        currentIndex = newIndex;
        
        if (oldIndex != 999) {
            
            [self exchangeItemIndex];

        }
        oldIndex = currentIndex;
    }
    
    
}

- (void)exchangeItemIndex{
    
    ImagePickItem *item = _itemList[oldIndex];
    
    [_itemList removeObjectAtIndex:oldIndex];
    
    [_itemList insertObject:item atIndex:currentIndex];
    
  
   
    int index = 0;
    
    for (ImagePickItem *item in _itemList) {
        
        if (item.index == index) {
            
            index ++;
            continue;
        }
        
         item.index = index;
        
        if (item.index == currentIndex) {
            
            index++;
            continue;
        }
       
        [UIView animateWithDuration:.35 animations:^{
        
            item.frame = [self getItemRect:index];
          
            
        }];
        
        index ++;
    }
    
    
}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self refreshView];
    });
    
}
#pragma mark 获取相册里具体的图片
- (void)sgetImageWithAsset:(PHAsset *)set Block:(void (^)(UIImage *image,NSDictionary *inf0))block{
    PHImageRequestOptions *option = [[PHImageRequestOptions alloc] init];
    //仅显示缩略图，不控制质量显示
    /**
     PHImageRequestOptionsResizeModeNone,
     PHImageRequestOptionsResizeModeFast, //根据传入的size，迅速加载大小相匹配(略大于或略小于)的图像
     PHImageRequestOptionsResizeModeExact //精确的加载与传入size相匹配的图像
     */
    option.resizeMode = PHImageRequestOptionsResizeModeExact;
    option.networkAccessAllowed = YES;
    //param：targetSize 即你想要的图片尺寸，若想要原尺寸则可输入PHImageManagerMaximumSize
    [[PHCachingImageManager defaultManager] requestImageForAsset:set targetSize:CGSizeMake([UIScreen mainScreen].bounds.size.width*5, [UIScreen mainScreen].bounds.size.width * set.pixelHeight/set.pixelWidth*5) contentMode:PHImageContentModeAspectFill options:option resultHandler:^(UIImage * _Nullable image, NSDictionary * _Nullable info) {
        if (info.allKeys.count > 10) {
            
            //解析出来的图片
            block(image,info);
        }
        
    }];
    
}

@end



extern int foo();

int bar() { return foo(); }

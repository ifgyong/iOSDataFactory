//
//  ViewController.m
//  CollectionView_多选尝试
//
//  Created by gyh on 16/7/21.
//  Copyright © 2016年 gyh. All rights reserved.
//

#import "ViewController.h"
#import "CellModel.h"
#import "CollectionViewCell.h"
#import "secondVC.h"

@interface ViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
{
    UICollectionView *_collectionView;
    BOOL IsTrue;
}
@property(nonatomic, strong)NSMutableArray *dataArray;
@property(nonatomic, strong)NSMutableArray *indexArray;
@property(nonatomic, strong)NSMutableArray *selectedArray;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    IsTrue = 0;
    _selectedArray = [NSMutableArray arrayWithCapacity:0];
    _indexArray = [NSMutableArray arrayWithCapacity:0];
    [self createUI];
    [self getData];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"collection Item多选";
}

-(void)createUI{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 104, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 60) collectionViewLayout:layout];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    [self.view addSubview:_collectionView];
    _collectionView.backgroundColor = [UIColor whiteColor];
    [_collectionView registerNib:[UINib nibWithNibName:@"CollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"CollectionViewCell"];
    //添加button(全选)
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(10, 69, 30, 30);
    button.layer.borderWidth = 1;
    button.layer.cornerRadius = 15;
    [self.view addSubview:button];
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 74, 80, 20)];
    titleLabel.text = @"全选";
    [self.view addSubview:titleLabel];
    UIButton *completeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    completeBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 80, 69, 60, 30);
    [completeBtn setTitle:@"完成" forState:UIControlStateNormal];
    [self.view addSubview:completeBtn];
    completeBtn.backgroundColor = [UIColor purpleColor];
    [completeBtn addTarget:self action:@selector(completeBtnClick) forControlEvents:UIControlEventTouchUpInside];
}

-(void)completeBtnClick{
    secondVC *secVC = [[secondVC alloc] init];
    secVC.dataArray = [NSMutableArray arrayWithCapacity:0];
    
    [secVC.dataArray addObjectsFromArray:_selectedArray];
    [self.navigationController pushViewController:secVC animated:YES];
}
-(void)buttonClick:(UIButton *)button{
    if (!IsTrue) {
        [_selectedArray addObjectsFromArray:_dataArray];
        for (int i = 0; i < _dataArray.count; i ++) {
            NSIndexPath *indexpath= [NSIndexPath indexPathForItem:i inSection:0];
            UICollectionViewCell *cell = [_collectionView cellForItemAtIndexPath:indexpath];
            cell.backgroundColor = [UIColor purpleColor];
            IsTrue = 1;
            button.backgroundColor = [UIColor purpleColor];
        }
    }else{
        [_selectedArray removeAllObjects];
        for (int i = 0; i < _dataArray.count; i ++) {
            NSIndexPath *indexpath= [NSIndexPath indexPathForItem:i inSection:0];
            UICollectionViewCell *cell = [_collectionView cellForItemAtIndexPath:indexpath];
            cell.backgroundColor = [UIColor clearColor];
            IsTrue = 0;
            button.backgroundColor = [UIColor clearColor];
        }
    }
}

-(void)getData{
    _dataArray = [NSMutableArray arrayWithCapacity:0];
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"人物写真" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:filePath];
    for (NSDictionary *dic in array) {
        CellModel *model = [[CellModel alloc] init];
        [model setValuesForKeysWithDictionary:dic];
        [_dataArray addObject:model];
    }
    [_collectionView reloadData];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CollectionViewCell" forIndexPath:indexPath];
    CellModel *model = _dataArray[indexPath.row];
    [cell refreshUI:model];
    return cell;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (_dataArray.count > 0) {
        return _dataArray.count;
    }
    return 0;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(120, 140);
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [_collectionView cellForItemAtIndexPath:indexPath];
    CellModel *model = _dataArray[indexPath.row];
    BOOL IsReal = 0;
    for (int i = 0; i < _selectedArray.count; i++) {
        if ([model isEqual:_selectedArray[i]]) {
            IsReal = 1;
              [_selectedArray removeObject:_selectedArray[i]];
            cell.backgroundColor = [UIColor clearColor];
             [_selectedArray addObject:model];
        }
    }
    if (IsReal) {
        [_selectedArray removeObject:model];
        cell.backgroundColor = [UIColor clearColor];
    }else{
        cell.backgroundColor = [UIColor purpleColor];
        [_selectedArray addObject:model];
    }
    NSLog(@"---%lu",(unsigned long)_selectedArray.count);
    for (int i = 0; i < _selectedArray.count; i ++) {
        CellModel *model = _selectedArray[i];
        NSLog(@"%@++++%@",model.imageInfo,model.imageName);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

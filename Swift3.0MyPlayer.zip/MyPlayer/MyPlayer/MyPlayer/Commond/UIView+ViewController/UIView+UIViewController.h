//
//  UIView+UIViewController.h
//  05 Responder
//
//  Created by wangxinkai on 14-8-23.
//  Copyright (c) 2014年 www.iphonetrain.com 无限互联3G学院. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface UIView (UIViewController)

- (UIViewController *)viewController;

@end

//
//  main.m
//  msgBtn
//
//  Created by 向彪 on 15/12/9.
//  Copyright © 2015年 Ritchie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

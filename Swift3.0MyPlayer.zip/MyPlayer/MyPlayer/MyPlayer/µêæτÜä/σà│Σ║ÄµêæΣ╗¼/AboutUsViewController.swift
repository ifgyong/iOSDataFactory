//
//  AboutUsViewController.swift
//  MyPlayer
//
//  Created by ybon on 2016/10/31.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class AboutUsViewController: BaseViewController {

    @IBOutlet weak var textV: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "关于我们";
        self.automaticallyAdjustsScrollViewInsets = false;
        textV.font = UIFont.systemFont(ofSize: 17);
        textV.text = "我的永恒：\n 是个人短时间内开发的一款软件，因为本人喜爱网游，在游戏里认识了许多难以忘怀的朋友，一款游戏，陪伴着我的青春。即使现在离开，也难以忘却以前。\n 这款软件主要是为了让所有热爱游戏的伙伴，记录自己的游戏经历，留住记忆，留住青春。";
        
    }
    

   
    

}

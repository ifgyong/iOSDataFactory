//
//  ViewController.h
//  CollectionView_多选尝试
//
//  Created by gyh on 16/7/21.
//  Copyright © 2016年 gyh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


//
//  MainTableViewController.h
//  折叠行
//
//  Created by yangyu on 16/4/1.
//  Copyright © 2016年 yangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *dataArray;

@end

//
//  AppDelegate.h
//  WTRecordMachine
//
//  Created by 隋文涛 on 16/5/28.
//  Copyright © 2016年 wintelsui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


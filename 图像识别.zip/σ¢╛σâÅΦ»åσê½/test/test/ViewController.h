//
//  ViewController.h
//  test
//
//  Created by shinefee on 15/12/8.
//  Copyright © 2015年 shinefee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)outPutImage:(id)sender;
@end

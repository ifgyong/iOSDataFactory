//
//  postPicViewController.h
//  Tx
//
//  Created by 苏州童讯 on 16/5/12.
//  Copyright © 2016年 Tx2015. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface postPicViewController : UIViewController

@end

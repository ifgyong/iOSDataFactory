//
//  PJViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/30.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class PJViewController: BaseViewController {

    
    @IBOutlet weak var titleTextF: UITextField!
    
    @IBOutlet weak var publisher: UITextField!
    
    @IBOutlet weak var bgView: UIView!
    var HUD:MBProgressHUD?;
    
    var pickView:ImagePickView?;
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "发表记忆";
        let user = BmobUser.current();
        if user?.username != nil {
            publisher.text = user?.username;
        }
        
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "发表", style: UIBarButtonItemStyle.done, target: self, action: #selector(publisherAction));
        pickView = ImagePickView.init(frame: bgView.bounds, withMaxCount:9);
        bgView.addSubview(pickView!);
    }
    
    func publisherAction(item:UIBarButtonItem){
        
        if titleTextF.text == "" || pickView?.imageLiast.count == 0 {
            self.showAlerController(title: "请填写完整信息", message: "信息不完整");
            return;
        }
        
        upMoreImage();
        
    }
    //多文件上传
    func upMoreImage(){
         HUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        //常用设置
        //小矩形的背景色
        HUD?.bezelView.color = UIColor.clear
        //显示的文字
        HUD?.label.text = "加载中1..."
        //细节文字
        HUD?.detailsLabel.text = "请耐心等待..."
        //设置背景,加遮罩
        HUD?.backgroundView.style = .solidColor //或SolidColor
        
        var i = 0;
        var arr:Array<String> = Array.init();
        for image in (pickView?.imageLiast)!{
//        let obj = BmobObject(className: "UserImageList");
        let data = UIImageJPEGRepresentation(image as! UIImage, 0.5);
        let imageName = "userImage.jpg"
        let file = BmobFile.init(fileName: imageName as String, withFileData: data);
        
        file?.saveInBackground { [weak file] (isSuccessful, error) in
            if isSuccessful {
                //如果文件保存成功，则把文件添加到file列
                let weakFile = file
                arr.insert((weakFile?.url)!, at: 0);
                i = i + 1;
                if i == self.pickView?.imageLiast.count{
                    self.publishJiyi(arr: arr);
                }
            }else{
                print("upload \(error)")
                i = i + 1;
                if i == self.pickView?.imageLiast.count{
                    self.publishJiyi(arr: arr);
                }
            }
            
        }
    }
    }
    
    
    func publishJiyi(arr:Array<String>){
        let gamescore:BmobObject = BmobObject(className: "HomeList")
        
        gamescore.setObject(titleTextF.text, forKey: "titleMessage")
        
        gamescore.setObject(arr, forKey: "imageList")
        
        gamescore.setObject(publisher.text, forKey: "publisherName")
        
        gamescore.saveInBackground { [weak gamescore] (isSuccessful, error) in
            self.HUD?.hide(animated: true, afterDelay: 0.01);
            if error != nil{
                self.showAlerController(title: "发布失败", message: "请重试");
                //发生错误后的动作
                print("error is \(error?.localizedDescription)")
            }else{
                //创建成功后会返回objectId，updatedAt，createdAt等信息
                //创建对象成功，打印对象值
                if let game = gamescore {
                    print("save success \(game)")
                    self.navigationController?.popViewController(animated: true);
                }
            }
        }
    }
    

}

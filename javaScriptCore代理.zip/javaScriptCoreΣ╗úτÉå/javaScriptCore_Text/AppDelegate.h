//
//  AppDelegate.h
//  javaScriptCore_Text
//   黄保健


#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


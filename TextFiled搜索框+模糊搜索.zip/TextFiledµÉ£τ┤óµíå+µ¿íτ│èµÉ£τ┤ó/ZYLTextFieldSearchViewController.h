//
//  ZYLTextFieldSearchViewController.h
//  ZYLTextFieldSearch
//
//  Created by zhuyuelong on 16/7/4.
//  Copyright © 2016年 zhuyuelong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYLTextFieldSearchViewController : UIViewController

@property (strong, nonatomic) UITableView *tableView;

@property (strong, nonatomic) UITableView *resultTableView;

/**
 *  数据数组
 */
@property (strong, nonatomic) NSMutableArray *dataArr;

/**
 *  搜索结果数组
 */
@property (strong, nonatomic) NSMutableArray *resultArr;

@property (strong, nonatomic) UITextField *search;

@property (copy, nonatomic) NSString *text;

@end

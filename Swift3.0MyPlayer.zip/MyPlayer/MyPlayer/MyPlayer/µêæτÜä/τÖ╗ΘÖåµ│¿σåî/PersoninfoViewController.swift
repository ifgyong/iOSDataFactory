//
//  PersoninfoViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class PersoninfoViewController: BaseViewController ,UINavigationControllerDelegate,UIImagePickerControllerDelegate{

    
    @IBOutlet weak var imageV: UIImageView!
    
    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var clsTextF: UITextField!
    
    @IBOutlet weak var address: UITextField!
    
    @IBOutlet weak var otherDesc: UITextField!
    
    
    @IBOutlet weak var sureBtn: UIButton!
    
    
    @IBOutlet weak var outBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "修改个人信息";
        sureBtn.layer.cornerRadius = 5;
        sureBtn.layer.masksToBounds = true;
        outBtn.layer.cornerRadius = 5;
        outBtn.layer.masksToBounds = true;
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(imageTapAction));
        tap.numberOfTapsRequired = 1;
        tap.numberOfTouchesRequired = 1;
        imageV.addGestureRecognizer(tap);
        let user = BmobUser.current();
        userName.text = user?.username;
        if user?.object(forKey: "imageUrl") != nil {
            imageV.sd_setImage(with: URL.init(string: user?.object(forKey: "imageUrl") as! String));
        }
        if user?.object(forKey: "desc") != nil {
           
            let descText = user?.object(forKey: "desc") as! NSString;
            let texArr = descText.components(separatedBy: " ");
            clsTextF.text = texArr[0];
            address.text = texArr[1];
            otherDesc.text = texArr[2];
        }
        
    }
    
    func imageTapAction(tap:UITapGestureRecognizer){

        let alertC = UIAlertController.init(title: "选择图片来源", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet);
        let carmaAction = UIAlertAction.init(title: "相机", style: UIAlertActionStyle.default) { (UIAlertActiono) in
            
            self.carma();
        }
        let photo = UIAlertAction.init(title: "图库", style: UIAlertActionStyle.default) { (UIAlertActiono) in
            
            self.photos();
        }
        let cancel = UIAlertAction.init(title: "取消", style: UIAlertActionStyle.cancel) { (UIAlertActiono) in
       
        }
        alertC.addAction(carmaAction);
        alertC.addAction(photo);
        alertC.addAction(cancel);
        self.present(alertC, animated: true, completion: nil);

        
    }
    //相机
    func carma(){
       
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) == false {
            return;
        }
        let pick = UIImagePickerController.init();
        pick.delegate = self;
        pick.sourceType = UIImagePickerControllerSourceType.camera;
        self.present(pick, animated: true, completion: nil);
    }
    //图库
    func photos(){
        let pick = UIImagePickerController.init();
        pick.delegate = self;
        pick.sourceType = UIImagePickerControllerSourceType.photoLibrary;
        self.present(pick, animated: true, completion: nil);

    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        let dic = info as NSDictionary;
        let image = dic.object(forKey: UIImagePickerControllerOriginalImage);

        let obj = BmobObject(className: "UserImageList");
        let data = UIImageJPEGRepresentation(image as! UIImage, 0.5);
        //        let dataString = reDate()
        let imageName = "userImage.jpg"
        let file = BmobFile.init(fileName: imageName as String, withFileData: data);
        
        file?.saveInBackground { [weak file] (isSuccessful, error) in
            if isSuccessful {
                //如果文件保存成功，则把文件添加到file列
                let weakFile = file
                obj?.setObject(weakFile, forKey: "image")

                obj?.saveInBackground(resultBlock: { (success, err) in
                    if err != nil {
                        print("save \(error)")
                    }
                    // print(file?.url);
                    
                    //保存链接到个人信息里
                    let user = BmobUser.current();
                    
                    user?.setObject(weakFile?.url, forKey: "imageUrl");
                    
                    
                    user?.updateInBackground(resultBlock: { (isSuccess, error) -> Void in
                        if error == nil{
                            self.imageV.sd_setImage(with: URL.init(fileURLWithPath: (weakFile?.url)!));
                        }else{
                            self.showAlerController(title: "头像修改失败",message: "请重新上传");
                        }
                    })

                    
                })
            }else{
                print("upload \(error)")
            }

        }
        
    picker.dismiss(animated: true, completion: nil);
}
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil);
    }
    @IBAction func SureBtnAction(_ sender: UIButton) {
        
        if clsTextF.text == nil || address.text == nil || otherDesc.text == nil {
            return;
        }
        let HUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        //常用设置
        //小矩形的背景色
        HUD.bezelView.color = UIColor.clear
        //显示的文字
        HUD.label.text = "加载中1..."
        //细节文字
        HUD.detailsLabel.text = "请耐心等待..."
        //设置背景,加遮罩
        HUD.backgroundView.style = .blur //或SolidColor
        
        let desc = String.init(format: "%@ %@ %@", clsTextF.text!, address.text!, otherDesc.text!)
        let user = BmobUser.current();
        user?.setObject(desc, forKey: "desc")
        user?.updateInBackground { (isSuccessful, error) in
            HUD.hide(animated: true, afterDelay: 0.01);
            if error == nil{
                self.navigationController?.popViewController(animated: true);
            }
            
        }
        
        
    }
   
    @IBAction func outBtnAction(_ sender: UIButton) {
        BmobUser.logout();
        self.navigationController?.popViewController(animated: true);
    }
    
    
    
}

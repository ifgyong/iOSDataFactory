//
//  AllTest6ViewController.h
//  MyLayout
//
//  Created by apple on 16/2/5.
//  Copyright (c) 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllTest6ViewController : UIViewController

@end

//
//  NDSearchStockCompanyModel.h
//  NDSearchTool
//
//  Created by NDMAC on 16/2/25.
//  Copyright © 2016年 NDEducation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NDSearchStockCompanyModel : NSObject

@property (nonatomic, copy) NSString *cSpell;
@property (nonatomic, copy) NSString *name;

@end

//
//  User.h
//  数组或模型的数据库存储
//
//  Created by Yang on 16/3/28.
//  Copyright © 2016年 Yang. All rights reserved.
//

#import "Tool_FMDBModel.h"

@interface User : Tool_FMDBModel<NSCoding>
@property(nonatomic,copy)NSString *name;
@end

//
//  TwoView.m
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import "TwoView.h"
#import "DotLabel.h"
@implementation TwoView

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor yellowColor];
//        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5.0f;
        
        DotLabel *dotLabel = [DotLabel new];
        dotLabel.userInteractionEnabled = YES;
         dotLabel.textAlignment = NSTextAlignmentCenter;
        dotLabel.frame = CGRectMake(-15, -15, 30, 30);
        dotLabel.textColor =[UIColor whiteColor];
        dotLabel.text = @"1";
        [self addSubview:dotLabel];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapSelect)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

-(void)tapSelect{
    if (_delegate && [_delegate respondsToSelector:@selector(changeViewFrame:)]) {
        [_delegate changeViewFrame:self];
    }
}
@end

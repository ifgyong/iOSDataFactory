//
//  FOLTest1ViewController.h
//  MyLayout
//
//  Created by apple on 16/2/19.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**浮动视图控制器测试1**/
@interface FOLTest1ViewController : UIViewController

@end

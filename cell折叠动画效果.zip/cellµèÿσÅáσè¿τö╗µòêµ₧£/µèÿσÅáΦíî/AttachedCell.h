//
//  AttachedCell.h
//  折叠行
//
//  Created by yangyu on 16/4/1.
//  Copyright © 2016年 yangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttachedCell : UITableViewCell

@end

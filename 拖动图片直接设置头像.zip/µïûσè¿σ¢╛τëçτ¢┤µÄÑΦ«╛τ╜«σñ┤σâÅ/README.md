# BHChoosePickerView
BHChoosePickerView 是一个头像匹配选择器的例子

![image](./intro.gif)
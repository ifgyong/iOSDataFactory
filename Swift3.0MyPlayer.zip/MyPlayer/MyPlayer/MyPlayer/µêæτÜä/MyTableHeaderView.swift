//
//  MyTableHeaderView.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class MyTableHeaderView: UIView {

    @IBOutlet weak var imageV: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var infoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib();
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(imageTapAction));
        tap.numberOfTapsRequired = 1;
        tap.numberOfTouchesRequired = 1;
        imageV.addGestureRecognizer(tap);
    }
    
    func imageTapAction(tap:UITapGestureRecognizer){
        let user = BmobUser.current();
        if user != nil {
            //进行操作
        }else{
            let viewC = LoginViewController.init(nibName: "LoginViewController", bundle: nil);
            viewC.hidesBottomBarWhenPushed = true;
            self.viewController().navigationController?.pushViewController(viewC, animated: true);
        }
        
        
    }
    
}

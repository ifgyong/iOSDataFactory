//
//  ViewController2.h
//  不规则截图
//
//  Created by macbook on 16/8/1.
//  Copyright © 2016年 macbook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end

//
//  ViewController.m
//  数组或模型的数据库存储
//
//  Created by Yang on 16/3/28.
//  Copyright © 2016年 Yang. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
#import "User.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Student *student = [[Student alloc]init];
    student.name = @"小黄";
    student.age = @"18";
    student.infos = @[@"1",@"hello",@"gg"];
    
    User *user = [[User alloc]init];
    user.name = @"userName";
    student.user = user;
    //保存数据到数据库（模型中的成员变量有数组与模型）
    //如果模型中的成员变量是数组或者自定义模型，就将数组或者自定义模型归档(NSKeyedArchive)为二进制数据，再存入数据库；从数据库取出数据时，将二进制数据解档（NSKeyedUnArchive）为数组或者自定义模型；
    [student save];
    //将数据库中的数据取出来
    NSArray *he = [Student findAll];
    for (int i = 0; i<he.count; i++) {
        Student *s =he[i];
        //查看数组数据能否成功读取
        NSLog(@"array:%@",s.infos);
        //查看模型数据能否成功读取
        NSLog(@"User:%@",s.user.name);
    }
    
}

@end

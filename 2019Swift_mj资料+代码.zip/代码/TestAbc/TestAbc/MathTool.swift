//
//  MathTool.swift
//  TestAbc
//
//  Created by MJ Lee on 2019/8/13.
//  Copyright © 2019 MJ Lee. All rights reserved.
//

public struct MathTool {
    public static func sum(_ a: Int, _ b: Int) -> Int {
        a + b
    }
}

//
//  ThreeView.h
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ThreeViewDelegate <NSObject>

-(void)changeViewFrame:(UIView *)view;

@end
@interface ThreeView : UIView
@property(assign,nonatomic)id<ThreeViewDelegate>delegate;
@end

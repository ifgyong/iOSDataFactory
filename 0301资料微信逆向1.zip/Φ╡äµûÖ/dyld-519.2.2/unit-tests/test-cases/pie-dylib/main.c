#include <stdio.h>
#include <stdbool.h>

extern void foo();

int main()
{
	foo();
	return 0;
}

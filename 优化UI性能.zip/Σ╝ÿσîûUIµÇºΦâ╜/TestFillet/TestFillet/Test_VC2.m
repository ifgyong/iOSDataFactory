//
//  Test_VC2.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/29.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC2.h"

@interface Test_VC2 ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation Test_VC2

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
    
    //http://blog.csdn.net/zhenyu5211314/article/details/24230581?utm_source=tuicool&utm_medium=referral
    //http://www.cocoachina.com/ios/20160315/15655.html
}

#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 600;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        
        UILabel *Label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 44)];
        Label.tag = 991;
        Label.text = @"真爱是存在的吗";
        Label.backgroundColor = [UIColor whiteColor];
        Label.clipsToBounds=YES;
        [cell.contentView addSubview:Label];
        
        UIImageView *imageV = [[UIImageView alloc]initWithImage:[self.class imageWithSize:CGSizeMake(60, 44) radius:22 Color:[UIColor purpleColor]]];
        imageV.frame = CGRectMake(180, 0, 60, 44);
        [cell.contentView addSubview:imageV];
        
        
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(260, 0, 44, 44)];
        button.backgroundColor = [UIColor whiteColor];
        [button setImage:[self.class imageWithSize:CGSizeMake(60, 44) radius:22 Color:[UIColor blueColor]] forState:UIControlStateNormal];
        button.layer.masksToBounds = YES;
        [cell.contentView addSubview:button];
        
        
        ///UIView的圆角产生离屏渲染,但是不会像素混合,但是没有masksToBounds就会像素混合
        UIView *view = [[UILabel alloc]initWithFrame:CGRectMake(320, 0, 60, 44)];
        view.backgroundColor = [UIColor colorWithPatternImage:[self.class imageWithSize:CGSizeMake(60, 44) radius:22 Color:[UIColor cyanColor]]];
        view.clipsToBounds=YES;
        [cell.contentView addSubview:view];
        
        
    }
    return cell;
}

+ (UIImage *)imageWithSize:(CGSize)sizeToFit radius:(CGFloat)radius  Color:(UIColor *)color{
    UIGraphicsBeginImageContextWithOptions(sizeToFit, true, UIScreen.mainScreen.scale);
    //设置上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    ///首先为了不让其有像素混合的问题,先把背景绘制出来
    CGContextSetFillColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextFillRect(context, CGRectMake(0, 0, sizeToFit.width, sizeToFit.height));
    CGContextDrawPath(context, kCGPathFillStroke); //根据坐标绘制路径

    //边框大小
    CGContextSetLineWidth(context, 1.0f);
    //边框颜色
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    //矩形填充颜色
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextSetAlpha(context, 1.0f);
    CGFloat height = sizeToFit.height;
    CGFloat width = sizeToFit.width;
    CGContextMoveToPoint(context, width/2 , 0);  // 开始上线中间开始
    CGContextAddArcToPoint(context, width , 0, width , height/2 , radius);  // 右上角角度
    CGContextAddArcToPoint(context, width, height , width/2, height , radius); // 右下角角度
    CGContextAddArcToPoint(context, 0, height, 0 , height/2, radius); // 左下角
    CGContextAddArcToPoint(context, 0 , 0, width/2 , 0 , radius); // 左上角
    CGContextDrawPath(context, kCGPathFillStroke); //根据坐标绘制路径
    
    UIImage *outImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    return outImage;
}
@end

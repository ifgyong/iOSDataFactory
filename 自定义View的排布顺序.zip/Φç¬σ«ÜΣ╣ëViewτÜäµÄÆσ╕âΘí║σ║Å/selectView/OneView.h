//
//  oneView.h
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol OneViewDelegate <NSObject>

-(void)changeViewFrame:(UIView *)view;

@end

@interface OneView : UIView
@property(assign,nonatomic)id<OneViewDelegate>delegate;

@end

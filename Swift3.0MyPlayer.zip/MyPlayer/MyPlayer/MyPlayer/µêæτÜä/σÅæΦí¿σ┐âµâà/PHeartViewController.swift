//
//  PHeartViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/30.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class PHeartViewController: BaseViewController {

    @IBOutlet weak var titleLabel: UITextField!
    
    @IBOutlet weak var publisherTextF: UITextField!
    
    @IBOutlet weak var textV: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "发表心情";
        let user = BmobUser.current();
        if user?.username != nil {
            publisherTextF.text = user?.username;
        }
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "发表", style: UIBarButtonItemStyle.done, target: self, action: #selector(publisherAction));
        
    }
    
    func publisherAction(item:UIBarButtonItem){
        
        if titleLabel.text == "" || textV.text == "" {
             self.showAlerController(title: "请填写完整信息", message: "信息不完整");
            return;
        }
        let HUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        //常用设置
        //小矩形的背景色
        HUD.bezelView.color = UIColor.clear
        //显示的文字
        HUD.label.text = "加载中1..."
        //细节文字
        HUD.detailsLabel.text = "请耐心等待..."
        //设置背景,加遮罩
        HUD.backgroundView.style = .solidColor //或SolidColor
        let gamescore:BmobObject = BmobObject(className: "HeartList")
        
        gamescore.setObject(titleLabel.text, forKey: "titleMessage")
     
        gamescore.setObject(textV.text, forKey: "descMessage")
        
        gamescore.setObject(publisherTextF.text, forKey: "publisher")
 
        gamescore.saveInBackground { [weak gamescore] (isSuccessful, error) in
            HUD.hide(animated: true, afterDelay: 0.01);
            if error != nil{
                //发生错误后的动作
                print("error is \(error?.localizedDescription)")
            }else{
                //创建成功后会返回objectId，updatedAt，createdAt等信息
                //创建对象成功，打印对象值
                if let game = gamescore {
                    print("save success \(game)")
                    self.navigationController?.popViewController(animated: true);
                }
            }
        }
        
        
        
    }
    
    

}

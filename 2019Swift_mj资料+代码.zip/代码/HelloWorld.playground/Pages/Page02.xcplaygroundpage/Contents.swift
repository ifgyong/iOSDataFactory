let a = 10
let b = 20
var c = a + b
c += 10
c += 20
print(c)



//
//  AlbumViewCell.h
//  相片相机
//
//  Created by ZJF on 16/6/1.
//  Copyright © 2016年 ZJF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumViewCell : UITableViewCell


@property (nonatomic,strong)UIImageView * iv;

@property (nonatomic,strong)UILabel * lbl;

@end

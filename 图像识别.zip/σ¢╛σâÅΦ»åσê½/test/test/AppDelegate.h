//
//  AppDelegate.h
//  test
//
//  Created by shinefee on 15/12/8.
//  Copyright © 2015年 shinefee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


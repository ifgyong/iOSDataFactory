//
//  AppDelegate.h
//  CustomTabBarController
//
//  Created by TF_man on 16/9/2.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


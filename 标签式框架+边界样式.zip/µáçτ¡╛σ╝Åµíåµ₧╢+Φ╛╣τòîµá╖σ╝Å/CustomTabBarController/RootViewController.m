//
//  RootViewController.m
//  CustomTabBarController
//
//  Created by TF_man on 16/9/2.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import "RootViewController.h"



@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    
    
}

@end

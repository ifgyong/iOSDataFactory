//
//  AppDelegate.h
//  数组或模型的数据库存储
//
//  Created by Yang on 16/3/28.
//  Copyright © 2016年 Yang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


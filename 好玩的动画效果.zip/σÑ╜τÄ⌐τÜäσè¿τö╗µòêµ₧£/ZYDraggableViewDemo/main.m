//
//  main.m
//  ZYDraggableViewDemo
//
//  Created by 张志延 on 16/8/26.
//  Copyright © 2016年 tongbu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

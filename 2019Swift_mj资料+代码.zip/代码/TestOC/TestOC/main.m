//
//  main.m
//  TestOC
//
//  Created by MJ Lee on 2019/8/4.
//  Copyright © 2019 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "TestOC-Swift.h"

@interface Person : NSObject

@end

@implementation Person

@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        id p = [Person new];
        int age = 10;
    }
    return 0;
}

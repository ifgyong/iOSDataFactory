//
//  dotLabel.h
//  selectView
//
//  Created by Bitaxon-mac on 16/4/19.
//  Copyright © 2016年 administrator-mac. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface DotLabel : UILabel

@end

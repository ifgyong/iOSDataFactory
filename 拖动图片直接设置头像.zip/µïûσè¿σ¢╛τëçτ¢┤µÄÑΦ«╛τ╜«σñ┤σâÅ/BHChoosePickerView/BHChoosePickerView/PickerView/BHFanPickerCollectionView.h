//
//  BHFanPickerCollectionView
//
//  Created by libohao on 15/8/5.
//
//

#import <UIKit/UIKit.h>

@interface BHFanPickerCollectionView : UICollectionView

@end

//
//  HomeViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit
let kScreenWidth = UIScreen.main.bounds.size.width;
let kScreenHeight = UIScreen.main.bounds.size.height;
let kScreen = UIScreen.main.bounds.size;
class HomeViewController: BaseViewController ,UITableViewDelegate,UITableViewDataSource{
    var _tableView:UITableView?;
    var dataArray:Array<Any>?;
    var pagesize:NSInteger?;
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "首页";
        pagesize = 20;
        self.view.backgroundColor = UIColor.white;
        self.automaticallyAdjustsScrollViewInsets = false;
        _tableView = UITableView.init(frame: CGRect.init(x: 0, y: 64, width: kScreenWidth, height: kScreenHeight-64-49));
        _tableView?.delegate = self;
        _tableView?.dataSource = self;
        _tableView?.tableFooterView = UIView.init();
        self.view.addSubview(_tableView!);
        loadData();
        let headerRe = MJRefreshStateHeader.init(refreshingTarget: self, refreshingAction: #selector(refresh));
        _tableView?.mj_header = headerRe;
        let footerRe = MJRefreshAutoStateFooter.init(refreshingTarget: self, refreshingAction: #selector(upLoad));
        _tableView?.mj_footer = footerRe;

    }
    //刷新
    func refresh(){
        loadData();
        _tableView?.mj_header.endRefreshing();
    }
    //加载
    func upLoad(){
        pagesize = pagesize! + 20;
        loadData();
        _tableView?.mj_footer.endRefreshing();
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 148;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataArray == nil {
            return 0;
        }
        return (dataArray?.count)!;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "homeCell");
        if cell == nil {
            
            cell = Bundle.main.loadNibNamed("HomeTableViewCell", owner: nil, options: nil)?.last as! HomeTableViewCell?;
        }
        let obj = dataArray?[indexPath.row] as! BmobObject;
        let ce = cell as! HomeTableViewCell?;
        ce?.titleLabel.text = obj.object(forKey: "titleMessage") as! String?;
//        let user = BmobUser.current();
        ce?.publisherLabel.text = obj.object(forKey: "publisherName") as! String?;
        ce?.imageList = obj.object(forKey: "imageList") as! Array<String>;

        return cell!;
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewC = HomeInfoViewController.init();
        viewC.hidesBottomBarWhenPushed = true;
        self.navigationController?.pushViewController(viewC, animated: true);
        let obj = dataArray?[indexPath.row] as! BmobObject;
        viewC.imageList = obj.object(forKey: "imageList") as! Array<String>;
        tableView.deselectRow(at: indexPath, animated: true);
    }
    
    func loadData(){
        let HUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        //常用设置
        //小矩形的背景色
        HUD.bezelView.color = UIColor.clear
        //显示的文字
        HUD.label.text = "加载中1..."
        //细节文字
        HUD.detailsLabel.text = "请耐心等待..."
        //设置背景,加遮罩
        HUD.backgroundView.style = .solidColor //或SolidColor
        
        //查找GameScore表
        let query = BmobQuery.init(className: "HomeList");
        query?.limit = pagesize!;
//        query?.order(byAscending: "updatedAt");//升序
        query?.order(byDescending: "updatedAt");//降序
//        let user = BmobUser.current();
        query?.whereKey("publisherName", equalTo: nil);
        query?.findObjectsInBackground { (array, error) in
            HUD.hide(animated: true, afterDelay: 0.01);
            self.dataArray = array;
            self._tableView?.reloadData();
            
        }
    }

    
}

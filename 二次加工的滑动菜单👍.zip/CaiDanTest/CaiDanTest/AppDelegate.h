//
//  AppDelegate.h
//  CaiDanTest
//
//  Created by KMJ on 16/8/4.
//  Copyright © 2016年 XT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


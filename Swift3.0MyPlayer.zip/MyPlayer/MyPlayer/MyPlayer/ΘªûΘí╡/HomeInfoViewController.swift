//
//  HomeInfoViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HomeInfoViewController: BaseViewController {
    var _imageList:Array<String>?;
    var imageList:Array<String>{
        set{
            _imageList = newValue;
        }
        get{
            return _imageList!;
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "详情";
        self.view.backgroundColor = UIColor.white;
        self.automaticallyAdjustsScrollViewInsets = false;
        let layout = UICollectionViewFlowLayout.init();
        layout.scrollDirection = UICollectionViewScrollDirection.horizontal;
        //垂直方向间距
        layout.minimumInteritemSpacing = 0;
        //水平方向间距
        layout.minimumLineSpacing = 0;
        layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        layout.itemSize = CGSize.init(width: kScreenWidth, height: kScreenHeight-64);
        let collect = HomeInfoCollectionView.init(frame: CGRect.init(x: 0, y: 64, width: kScreenWidth, height: kScreenHeight-64), collectionViewLayout: layout)
        self.view.addSubview(collect);
        if _imageList != nil {
            
            collect.imageList = _imageList!;
        }
        
    }
    

    
    

}

//
//  AppDelegate.h
//  DBSphereTagCloud
//
//  Created by Xinbao Dong on 14/9/1.
//  Copyright (c) 2014年 Xinbao Dong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


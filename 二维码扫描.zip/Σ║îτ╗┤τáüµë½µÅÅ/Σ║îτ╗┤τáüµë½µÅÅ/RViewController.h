//
//  RViewController.h
//  二维码扫描
//
//  Created by feique on 16/9/12.
//  Copyright © 2016年 com.feique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RViewController : UIViewController

@end

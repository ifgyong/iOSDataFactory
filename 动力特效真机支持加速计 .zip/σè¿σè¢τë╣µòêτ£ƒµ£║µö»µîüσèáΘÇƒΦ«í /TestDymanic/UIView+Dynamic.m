//
//  UIView+Dynamic.m
//  TestDymanic
//
//  Created by lee on 16/1/21.
//  Copyright © 2016年 lee. All rights reserved.
//

#import "UIView+Dynamic.h"

@implementation UIView (Dynamic)
-(UIDynamicItemCollisionBoundsType)collisionBoundsType{
    return UIDynamicItemCollisionBoundsTypeEllipse;
}
@end

# ImageFilter：ios下图像滤镜Demo

示例：

![image](http://i3.tietuku.com/023008ef57cca56b.jpg)

利用stroyboard 和 xib实现，通俗易懂。

English: The IOS Image Filter 

It 's easy to understand and implement by Storyboard and Xib.

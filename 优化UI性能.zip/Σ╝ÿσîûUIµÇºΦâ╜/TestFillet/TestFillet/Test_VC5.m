//
//  Test_VC5.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/30.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC5.h"

@interface Test_VC5 ()

@end

@implementation Test_VC5

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    UIImage *iamge = [UIImage imageNamed:@"lena.png"];
    
    UIImageView *imageV = [[UIImageView alloc]initWithImage:[self scaleImage:iamge size:CGSizeMake(512/4, 512/4)]];
    imageV.frame = CGRectMake(20, 110, 512/4, 512/4);
    [self.view addSubview:imageV];
    
    
    UIImageView *imageV1 = [[UIImageView alloc]initWithImage:[self scaleNoImage:iamge size:CGSizeMake(40, 40)]];
    imageV1.frame = CGRectMake(20, 250, 40, 40);
    [self.view addSubview:imageV1];
}

// 非等比缩放，生成的图片可能会被拉伸
- (UIImage *)scaleNoImage:(UIImage *)image size:(CGSize)size {
    UIGraphicsBeginImageContextWithOptions(size, true, [UIScreen mainScreen].scale);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *outImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return outImage;
}

// 等比缩放
- (UIImage *)scaleImage:(UIImage *)image size:(CGSize)size {
    CGFloat scale =  [UIScreen mainScreen].scale;
    
    // 这一行至关重要
    // 不要直接使用UIGraphicsBeginImageContext(size);方法
    // 因为控件的frame与像素是有倍数关系的
    // 比如@1x、@2x、@3x图，因此我们必须要指定scale，否则黄色去不了
    // 因为在5以上，scale为2，6plus scale为3，所生成的图是要合苹果的
    // 规格才能正常
    UIGraphicsBeginImageContextWithOptions(size, true, scale);
    
    CGFloat rateWidth = size.width / image.size.width;
    CGFloat rateHeight = size.height / image.size.height;
    
    CGFloat rate = MIN(rateHeight, rateWidth);
    CGSize aspectFitSize = CGSizeMake(image.size.width * rate, image.size.height * rate);
    [image drawInRect:CGRectMake(0, 0, aspectFitSize.width, aspectFitSize.height)];
    UIImage *outImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return outImage;
}

@end

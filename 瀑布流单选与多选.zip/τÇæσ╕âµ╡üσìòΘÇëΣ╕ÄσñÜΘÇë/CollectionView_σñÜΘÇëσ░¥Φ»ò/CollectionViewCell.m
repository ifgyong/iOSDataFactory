//
//  CollectionViewCell.m
//  CollectionView_多选尝试
//
//  Created by gyh on 16/7/21.
//  Copyright © 2016年 gyh. All rights reserved.
//

#import "CollectionViewCell.h"
#import "CellModel.h"
@interface CollectionViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *mainImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end

@implementation CollectionViewCell


-(void)refreshUI:(CellModel *)model{
    self.mainImageView.image = [UIImage imageNamed:model.imageName];
    self.nameLabel.text = model.imageInfo;
}

- (void)awakeFromNib {
    // Initialization code
}

@end

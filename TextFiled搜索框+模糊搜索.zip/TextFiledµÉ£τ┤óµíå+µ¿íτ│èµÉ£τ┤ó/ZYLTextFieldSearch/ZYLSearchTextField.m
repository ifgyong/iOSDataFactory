//
//  ZYLSearchTextField.m
//  ZYLTextFieldSearch
//
//  Created by zhuyuelong on 16/7/4.
//  Copyright © 2016年 zhuyuelong. All rights reserved.
//

#import "ZYLSearchTextField.h"

@implementation ZYLSearchTextField

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

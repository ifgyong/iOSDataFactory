//
//  NDSearchStockModel.h
//  NDSearchTool
//
//  Created by NDMAC on 16/2/22.
//  Copyright © 2016年 NDEducation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NDSearchStockModel : NSObject

@property (nonatomic, copy) NSString *pingyin;
@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *name;

@end

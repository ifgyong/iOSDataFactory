# ocr
ocr，图像识别，文字识别，文字处理，调的百度的接口实现文字识别
## 练习一下 ，项目怎么写简介READ

#### 图片如何导入
![qrview](http://iosddimage.qiniudn.com/QRView.PNG)

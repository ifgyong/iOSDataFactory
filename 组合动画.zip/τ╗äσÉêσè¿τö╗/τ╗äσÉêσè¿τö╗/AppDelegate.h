//
//  AppDelegate.h
//  组合动画
//
//  Created by JiaFuyang on 15/12/14.
//  Copyright © 2015年 JiaFuyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  Test_VC3.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/29.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC3.h"

@interface Test_VC3 ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation Test_VC3

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
    

}

#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 600;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        
        UILabel *Label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 44)];
        Label.tag = 991;
        Label.text = @"真爱是存在的吗";
        Label.backgroundColor = [UIColor whiteColor];
        Label.clipsToBounds=YES;
        [cell.contentView addSubview:Label];
        
        UIImage *iamge = [UIImage imageNamed:@"lena.png"];
        
        UIImageView *imageV = [[UIImageView alloc]initWithImage:[self UIBezierPathClip:iamge cornerRadius:512/2]];
        imageV.frame = CGRectMake(180, 0, 60, 44);
        [cell.contentView addSubview:imageV];
        
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(260, 0, 44, 44)];
        button.backgroundColor = [UIColor whiteColor];
        [button setImage:[self UIBezierPathClip:iamge cornerRadius:512/2] forState:UIControlStateNormal];
        button.layer.masksToBounds = YES;
        [cell.contentView addSubview:button];

        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(320, 0, 60, 44)];
        view.layer.contents = (__bridge id _Nullable)([self UIBezierPathClip:iamge cornerRadius:512/2].CGImage);
//        view.backgroundColor = [UIColor whiteColor];
        view.clipsToBounds=YES;
        [cell.contentView addSubview:view];
        
    }
    return cell;
}

// UIBezierPath 裁剪
- (UIImage *)UIBezierPathClip:(UIImage *)img cornerRadius:(CGFloat)c {
    int w = img.size.width * img.scale;
    int h = img.size.height * img.scale;
    CGRect rect = CGRectMake(0, 0, w, h);
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(w, h), true, 1.0);
    //设置上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    ///首先为了不让其有像素混合的问题,先把背景绘制出来
    CGContextSetFillColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextFillRect(context, CGRectMake(0, 0, w, h));
    CGContextDrawPath(context, kCGPathFillStroke); //根据坐标绘制路径
    [[UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:c] addClip];
    [img drawInRect:rect];
    UIImage *ret = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return ret;
}

@end

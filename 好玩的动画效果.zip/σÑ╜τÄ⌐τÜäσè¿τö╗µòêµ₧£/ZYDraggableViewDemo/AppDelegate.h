//
//  AppDelegate.h
//  ZYDraggableViewDemo
//
//  Created by 张志延 on 16/8/26.
//  Copyright © 2016年 tongbu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


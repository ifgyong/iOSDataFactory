//
//  ZYImageWaterFlowLayout.h
//  图片选择
//
//  Created by z x h  on 2016/10/22.
//  Copyright © 2016年 ybon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYImageWaterFlowLayout : UICollectionViewFlowLayout
/**<PHAsset *>*/
@property (nonatomic, strong) NSArray *imgNameArr;


@property (nonatomic, copy)void(^blockHeight)(double height);

@end

//
//  NSString+StringToWords.h
//  CodeView
//
//  Created by pxh on 16/8/16.
//  Copyright © 2016年 MS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (StringToWords)

-(NSArray* )words;

@end

//
//  secondVC.m
//  CollectionView_多选尝试
//
//  Created by gyh on 16/7/21.
//  Copyright © 2016年 gyh. All rights reserved.
//

#import "secondVC.h"
#import "CellModel.h"

@interface secondVC ()

@end

@implementation secondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
//    NSLog(@"%lu",(unsigned long)_dataArray.count);
//    for (int i = 0; i < self.dataArray.count; i++) {
//        CellModel *model = self.dataArray[i];
//        NSLog(@"%@",model.imageName);
//    }
    [self createUI];
}

-(void)createUI{
    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    [self.view addSubview:textView];
    textView.backgroundColor = [UIColor grayColor];
    NSString *str = @"";
    for (int i = 0; i < self.dataArray.count; i++) {
        CellModel *model = _dataArray[i];
        str = [NSString stringWithFormat:@"%@\n%@",str,model.imageName];
    }
    textView.text = str;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  RegistViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class RegistViewController: BaseViewController {
    @IBOutlet weak var userNameTextF: UITextField!
    
    @IBOutlet weak var passWordTextF: UITextField!
    
    @IBOutlet weak var registerBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "注册";
      
        registerBtn.layer.cornerRadius = 5;
        registerBtn.layer.masksToBounds = true;
        
    }
    

    @IBAction func registerBtnAction(_ sender: UIButton) {
        if userNameTextF.text == nil || passWordTextF.text == nil {
            return;
        }
        let HUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        
        //常用设置
        //小矩形的背景色
        HUD.bezelView.color = UIColor.clear
        //显示的文字
        HUD.label.text = "加载中1..."
        //细节文字
        HUD.detailsLabel.text = "请耐心等待..."
        //设置背景,加遮罩
        HUD.backgroundView.style = .blur //或SolidColor
        
        let user = BmobUser()
        user.username = userNameTextF.text;
        user.password = passWordTextF.text;
        user.setObject(18, forKey: "age");
        
        user.signUpInBackground { (isSuccessful, error) in
            HUD.hide(animated: true, afterDelay: 0.01);
            if isSuccessful {
                
                self.navigationController?.popToRootViewController(animated: true);
                
            }else{
               self.showAlerController(title: "注册失败",message: "");
            }
        }
    }
    
    
}

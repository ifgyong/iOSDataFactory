//
//  OneViewController.m
//  CustomTabBarController
//
//  Created by TF_man on 16/9/2.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import "OneViewController.h"

@interface OneViewController ()

@end

@implementation OneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    

    
    
    
}
@end

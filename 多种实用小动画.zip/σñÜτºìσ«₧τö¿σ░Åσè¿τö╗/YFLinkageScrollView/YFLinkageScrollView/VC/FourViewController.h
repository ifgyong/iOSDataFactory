//
//  FourViewController.h
//  YFLinkageScrollView
//
//  Created by Wolf on 16/3/25.
//  Copyright © 2016年 许毓方. All rights reserved.
//

#import "BasicViewController.h"

@interface FourViewController : BasicViewController

@end

//
//  main.m
//  ThinkYouPossess
//
//  Created by qianfeng on 15-3-3.
//  Copyright (c) 2015年 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LJWAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LJWAppDelegate class]));
    }
}

//
//  ZYImageCollectionViewController.m
//  图片选择
//
//  Created by z x h  on 2016/10/22.
//  Copyright © 2016年 ybon. All rights reserved.
//

#import "ZYImageCollectionViewController.h"
#import "ZYImageWaterFlowLayout.h"
#import "GetPhotLibaryImage.h"
@interface ZYImageCollectionViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

/**相册集合*/
@property(nonatomic,strong)PHAssetCollection *assetCollection;

@end

@implementation ZYImageCollectionViewController


static NSString * const reuseIdentifier = @"cellID";


- (void)creatNavigationButton{
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"确定    " style:UIBarButtonItemStyleDone target:self action:@selector(rightButtonAction:)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(leftButtonAction:)];
    
    
}
- (void)rightButtonAction:(UIBarButtonItem *)button{
    
    //代理对象存在，代理实现了代理方法
    if (self.delegate && [self.delegate respondsToSelector:@selector(imagePickerSelected:)]) {
        
        
        //是用代理对象调用代理对象类里面得代理方法
        [self.delegate imagePickerSelected:_selectedImage];
        
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)leftButtonAction:(UIBarButtonItem *)button{
    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)loadData{
  
    
    [GetPhotLibaryImage getLibaryPhotosAllImageBlock:^(NSArray *assetArray) {
        
        _assetArray = [NSMutableArray arrayWithArray:assetArray];
        _selectedImage = [[NSMutableArray alloc] init];
        
        ZYImageWaterFlowLayout *layout = [[ZYImageWaterFlowLayout alloc] init];
        
        layout.imgNameArr = _assetArray;
        dispatch_async(dispatch_get_main_queue(), ^{
            // 切换布局
            self.collectionView.collectionViewLayout = layout;
            [layout setBlockHeight:^(double h) {
//                if (h != self.collectionView.contentSize.height) {
//                
                    self.collectionView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, h);
//                }
//
//                
            }];
//            [self.collectionView reloadData];
        });
        
    }];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]];
    self.collectionView.backgroundColor = [UIColor clearColor];
    [self creatNavigationButton];
    [self loadData];
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
}

#pragma mark <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _assetArray.count;
    
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *item = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    item.backgroundColor = [UIColor orangeColor];
    
    if (![item.contentView viewWithTag:2010]) {
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:item.contentView.bounds];
        imageview.tag = 2010;
        
        [item.contentView addSubview:imageview];
        
        //选中按钮
        UIImageView *selectImage = [[UIImageView alloc] initWithFrame:CGRectMake(item.contentView.frame.size.width -18, 0, 18, 18)];
        selectImage.hidden = YES;
        selectImage.tag = 2011;
        
        selectImage.image = [UIImage imageNamed:@"checkmark"];
        [item.contentView addSubview:selectImage];
        
        imageview.userInteractionEnabled = YES;
        selectImage.userInteractionEnabled = YES;
        
    }
    
    
    UIImageView *imageV = (UIImageView *)[item.contentView viewWithTag:2010];
    imageV.frame = CGRectMake(0, 0, item.bounds.size.width, item.bounds.size.height);
    PHAsset *aset = _assetArray[indexPath.row];
    [GetPhotLibaryImage getImageWithAsset:aset Block:^(UIImage *image, NSDictionary *inf0) {
        
        imageV.image = image;
    }];
//    imageV.backgroundColor = [UIColor orangeColor];
    //选中按钮
    UIImageView *selectImage = (UIImageView *)[item.contentView viewWithTag:2011];
    
    selectImage.image = [UIImage imageNamed:@"checkmark"];
    
    selectImage.hidden = ![_selectedImage containsObject:_assetArray[indexPath.row]];
//    item.layer.masksToBounds = YES;
    return item;
}

#pragma mark collectionView deleget
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    UIImageView *selectImageView = (UIImageView *)[cell.contentView viewWithTag:2011];
    
    if (selectImageView.hidden == YES) {
        
        if (_selectedImage.count >= _maxImageCount) {
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"图片过多" message:[NSString stringWithFormat:@"少于%ld张",_maxImageCount] preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
            [alertC addAction:action];
            [self presentViewController:alertC animated:YES completion:nil];
            return;
        }
        [_selectedImage addObject:_assetArray[indexPath.row]];
        selectImageView.hidden = NO;
        
    }else{
        
        [_selectedImage removeObject:_assetArray[indexPath.row]];
        
        selectImageView.hidden = YES;
        
    }
    
    
}
- (void)setSelectedImage:(NSMutableArray *)selectedImage{
    _selectedImage = [NSMutableArray arrayWithArray:selectedImage];
}

@end

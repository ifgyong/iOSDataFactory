//
//  AwardViewController.swift
//  MyPlayer
//
//  Created by ybon on 2016/10/31.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class AwardViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "打赏我";
        
    }
    

   
    

}

//
//  CellModel.h
//  CollectionView_多选尝试
//
//  Created by gyh on 16/7/21.
//  Copyright © 2016年 gyh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CellModel : NSObject

@property(nonatomic ,copy)NSString *imageInfo;
@property(nonatomic, copy)NSString *imageName;

@end

//
//  ViewController.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/28.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "ViewController.h"
#import "YYFPSLabel.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *arrayVC;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.title = @"各种切圆角大法,以及性能问题";
    
    //请仔细阅读调试方法的含义:像素混合 Color Blended Layers http://www.jianshu.com/p/db6602413fa3
    //下面这么写,可以达到像素完全没有混合的效果,已经极致了,各种点的概念太多,不在此概述
    self.navigationController.navigationBar.layer.masksToBounds = YES;
    for (UIView *vi in self.navigationController.navigationBar.subviews) {
        vi.backgroundColor = [UIColor whiteColor];
        vi.alpha = 1.0f;
        vi.layer.masksToBounds = YES;
        for (UIView *vii in vi.subviews) {
            vii.backgroundColor = [UIColor whiteColor];
            vii.alpha = 1.0f;
            vii.layer.masksToBounds = YES;
            for (UIView *viii in vii.subviews) {
                NSLog(@"%@ %@",viii,viii.superview);

                if ([viii isKindOfClass:NSClassFromString(@"_UIVisualEffectFilterView")]) {
                    viii.backgroundColor = [UIColor whiteColor];
                    viii.alpha = 1.0f;
                    ///高斯模糊效果移除,则像素混合没有Color Blended Layers测试达到最优化
                    [viii removeFromSuperview];
                }else{
                    viii.backgroundColor = [UIColor whiteColor];
                    viii.alpha = 1.0f;
                    viii.layer.masksToBounds = YES;
                    ///为了不让其离屏渲染,整个屏幕都是屎黄色(离屏渲染),(好像日了狗了一样的心情,这_UIVisualEffectBackdropView有毒)
                    [viii removeFromSuperview];
                }
            }
        }
    }
    /*
     https://yq.aliyun.com/articles/37063
     https://github.com/100mango/zen/blob/master/WWDC心得：Advanced%20Graphics%20and%20Animations%20for%20iOS%20Apps/Advanced%20Graphics%20and%20Animations%20for%20iOS%20Apps.md
     
     http://adad184.com/2015/07/13/improve-performance-with-mkmapview/
     
     http://weibo.com/ttarticle/p/show?id=2309404058068643105152  彻底了解像素混合和离屏渲染,各种性能优化的问题
     
     有以下方式可以引起离屏渲染：
     shouldRasterize设置为YES masks（遮罩） shadows（阴影） edge antialiasing（抗锯齿） group opacity（不透明） cornerRadius+clipToBounds/maskToBounds设置圆角 重写drawRect交由CPU渲染 如何检测离屏渲染
     */
    
    /*
     UIImageView的正常一张图片(没有透明通道,不切割圆角)不会有像素混合问题也不会有离屏渲染问题
     其他的UIView多多少少都会有些像素混合问题,动了layer会有离屏渲染
     
     */
    
    /* 
     下面这2个不做什么太大考虑,只有在解决像素混合和离屏渲染之后才进行考虑优化
     color misaligned images
     图片像素不对齐（也就是图片带alpha通道）时，会在图片上面加一层洋红色来标识；而图片被缩放时，会加一层黄色来标识
     http://ios.jobbole.com/84151/
     Color Copied Images Copied Image选项可以标注应用绘制时被Core Animation复制的图片，标注成蓝绿色。
     http://blog.csdn.net/volcan1987/article/details/22620947
     */
    
    
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
    
    YYFPSLabel *yyLab = [[YYFPSLabel alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.view.frame)-60, CGRectGetHeight(self.view.frame)-30, 60, 30)];
    [self.navigationController.view addSubview:yyLab];
    arrayVC = @[@"2句话最简切圆角",@"模型图层配合贝塞尔",@"不要离屏渲染和像素混合,纯颜色图片",@"贝塞尔配合Graphics切图片圆角",@"Context切图片圆角",@"图片像素对齐"].mutableCopy;
    /*
     在这个地方按照我的综合考虑:模型图层配合贝塞尔切圆角 是最好的方式,大家按照各种场景进行模拟测试.
     每个方式都有优劣,原因和解决方案已经在给出,请大家仔细了解概念和点,进行理解!
     具体业务场景,请具体选择
     这个测试只是为了优化而优化,一切为了1s60的帧率来优化!
     */
}

#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arrayVC.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.textLabel.backgroundColor = [UIColor whiteColor];
        cell.textLabel.layer.masksToBounds = YES;
        //光栅化,产生离屏渲染,这个地方最好不要使用,若有其他要求才使用,
//        cell.layer.shouldRasterize = YES;
//        cell.layer.rasterizationScale = [UIScreen mainScreen].scale;
    }
    cell.textLabel.text = arrayVC[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSArray *array = @[@"Test_VC",@"Test_VC1",@"Test_VC2",@"Test_VC3",@"Test_VC4",@"Test_VC5"].mutableCopy;
    Class VC = NSClassFromString(array[indexPath.row]);
    if (VC) {
        UIViewController *aVC = [VC new];
        aVC.title = arrayVC[indexPath.row];
        [self.navigationController pushViewController:aVC animated:YES];
    }
}

@end

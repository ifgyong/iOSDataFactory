//
//  WelcomeViewController.h
//  TankWar1
//
//  Created by yq on 15/10/8.
//  Copyright © 2015年 test. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface WelcomeViewController : UIViewController

@property (weak, nonatomic) ViewController *viewController;

@end

//
//  Test2ViewController.h
//  MyLayout
//
//  Created by apple on 15/6/21.
//  Copyright (c) 2015年 欧阳大哥. All rights reserved.
//

#import <UIKit/UIKit.h>

/*子视图的隐藏和显示以及滚动条视图的处理*/
@interface LLTest2ViewController : UIViewController

@end

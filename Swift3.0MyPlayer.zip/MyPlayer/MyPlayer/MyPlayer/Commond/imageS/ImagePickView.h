//
//  ImagePickView.h
//  图片选取Demo
//
//  Created by Mac on 15-11-2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePickItem.h"
#import "ZYImageCollectionViewController.h"

@interface ImagePickView : UIView<ImagePickerControllerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>
/**可选的最大图片数量，默认是三张*/
@property (nonatomic, assign) NSInteger maxImageCount;
//9以后的方法
@property (nonatomic,strong) PHPhotoLibrary *newlibary;

@property (nonatomic,strong) NSMutableArray *imageLiast;

@property (nonatomic,strong) NSMutableArray *itemList;
- (id)initWithFrame:(CGRect)frame withMaxCount:(NSInteger)maxCount;
@end

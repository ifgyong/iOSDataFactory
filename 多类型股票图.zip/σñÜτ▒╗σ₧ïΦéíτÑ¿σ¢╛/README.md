# JHChart

- 4.14日上传第一版  折线图 包括不同的象限内折线图 将会持续更新 效果图如下
- 5.3日上传更新版  新增了饼状图初稿
- 6.5日添加了环状图
- 8.8日添加了柱状图
- 8.25日添加了表格图

![image](https://raw.githubusercontent.com/China131/JHChart/master/JHChartDemo/GIFResource/0011.gif)

int compress()
{
	return 0;
}

//
//  DataModel.m
//  JLWaterfallFlow
//
//  Created by Jasy on 16/1/25.
//  Copyright © 2016年 Jasy. All rights reserved.
//

#import "DataModel.h"

@implementation DataModel

@end

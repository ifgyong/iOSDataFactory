//
//  UIView+Dynamic.h
//  TestDymanic
//
//  Created by lee on 16/1/21.
//  Copyright © 2016年 lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Dynamic)<UIDynamicItem>
@end

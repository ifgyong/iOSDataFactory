//
//  ViewController.swift
//  MyPlayer
//
//  Created by z x h  on 2016/10/29.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        // 延迟执行代码
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
            //切换window的跟视图
            BaseTabBarController.changeKeyWindowRootViewController();
        }
        
        
        
    }


}


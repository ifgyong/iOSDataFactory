//
//  GetPhotLibaryImage.h
//  图片选择
//
//  Created by z x h  on 2016/10/21.
//  Copyright © 2016年 ybon. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Photos/Photos.h>
@interface GetPhotLibaryImage : NSObject


#pragma mark 获取相册中所有的Asset对象
+ (void)getLibaryPhotosAllImageBlock:(void (^)(NSArray *assetArray))block;

#pragma mark 获取所有相册列表
+ (void)getAllPhotoNameListBlock:(void (^)(NSArray *aassetCollectionArray,NSArray *nameArray))block;
#pragma mark 获取一个相册中，所有图片 asset集合
+ (void)getAllImageOfPhotoLibaryWithPHAssetCollection:(PHAssetCollection *)assetCollection Block:(void (^)(NSArray *assetArray))block;
#pragma mark 获取相册中，具体的图片
+ (void)getImageWithAsset:(PHAsset *)set Block:(void (^)(UIImage *image,NSDictionary *inf0))block;
#pragma mark 获取相册英文名对应的汉语
+ (NSString *)transformAblumTitle:(NSString *)title;


@end

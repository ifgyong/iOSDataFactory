//
//  AppDelegate.h
//  msgBtn
//
//  Created by 向彪 on 15/12/9.
//  Copyright © 2015年 Ritchie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


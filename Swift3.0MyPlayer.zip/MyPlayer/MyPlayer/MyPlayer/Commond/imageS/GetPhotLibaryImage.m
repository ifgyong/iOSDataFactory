//
//  GetPhotLibaryImage.m
//  图片选择
//
//  Created by z x h  on 2016/10/21.
//  Copyright © 2016年 ybon. All rights reserved.
//

#import "GetPhotLibaryImage.h"

@implementation GetPhotLibaryImage


#pragma mark 获取相册中所有的Asset对象
+ (void)getLibaryPhotosAllImageBlock:(void (^)(NSArray *assetArray))block{
    NSMutableArray *allAssetArray = [[NSMutableArray alloc] init];
    [self getAllPhotoNameListBlock:^(NSArray *aassetCollectionArray, NSArray *nameArray) {
        
        //创建一个并行线程队列
        dispatch_queue_t queue_1 = dispatch_queue_create("queue_1", DISPATCH_QUEUE_CONCURRENT);
        //创建一个串行队列
        //    dispatch_queue_t queue_2 = dispatch_queue_create("queue_2", DISPATCH_QUEUE_SERIAL);
        //确定任务数量
        size_t count = aassetCollectionArray.count;
        __block NSInteger j = 0;
        //异步提交遍历数组
        dispatch_apply(count, queue_1, ^(size_t i) {
            
            PHAssetCollection *collection = aassetCollectionArray[i];
            [NSThread sleepForTimeInterval:0.2];
            [self getAllImageOfPhotoLibaryWithPHAssetCollection:collection Block:^(NSArray *assetArray) {
                [allAssetArray addObjectsFromArray:assetArray];
                j++;
                if (j == count-1) {
                    block(allAssetArray);
                   
                }
                
            }];
            
        });
        
    }];
    
}


#pragma mark 获取所有相册列表
+ (void)getAllPhotoNameListBlock:(void (^)(NSArray *aassetCollectionArray,NSArray *nameArray))block{
    NSMutableArray *collectionAarray = [[NSMutableArray alloc] init];
    NSMutableArray *nameArr = [[NSMutableArray alloc] init];
    
    // 获取用户自定义相册
    PHFetchResult *CustomResult = [PHCollectionList fetchTopLevelUserCollectionsWithOptions:nil];
    
    for (PHCollection *collection in CustomResult) {
        if ([collection isKindOfClass:[PHAssetCollection class]]) {
            PHAssetCollection *assetCollection = (PHAssetCollection *)collection;
            NSLog(@"-相册名字:%@",assetCollection.localizedTitle);//
            [collectionAarray addObject:assetCollection];
            [nameArr addObject:assetCollection.localizedTitle];
        }
    }

    
#pragma mark 获取所有相册列表
    PHFetchResult *smartAlbums = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    [smartAlbums enumerateObjectsUsingBlock:^(PHAssetCollection * _Nonnull collection, NSUInteger idx, BOOL *stop) {
        PHAssetCollection *assetCollection = (PHAssetCollection *)collection;
//        if ([assetCollection.localizedTitle isEqualToString:@"Camera Roll"]) {  
//        }
        [collectionAarray addObject:assetCollection];
        [nameArr addObject:assetCollection.localizedTitle];
        NSLog(@"相册名字:%@",collection.localizedTitle);//
        
        if (collectionAarray.count == smartAlbums.count) {
            block(collectionAarray,nameArr);
        }
        
    }];
    
    
}
#pragma mark 获取一个相册中，所有图片 asset集合
+ (void)getAllImageOfPhotoLibaryWithPHAssetCollection:(PHAssetCollection *)assetCollection Block:(void (^)(NSArray *assetArray))block{
    PHFetchResult *fetchResult = [PHAsset fetchAssetsInAssetCollection:assetCollection options:nil];// 获取到你想要的图片集合
    NSMutableArray *_nAssetArray = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < fetchResult.count; i++) {// 遍历里面所有的图片资源
        PHAsset *asset = fetchResult[i];
        [_nAssetArray addObject:asset];
        
    }
    block(_nAssetArray);
}
#pragma mark 获取相册里具体的图片
+ (void)getImageWithAsset:(PHAsset *)set Block:(void (^)(UIImage *image,NSDictionary *inf0))block{
    PHImageRequestOptions *option = [[PHImageRequestOptions alloc] init];
    //仅显示缩略图，不控制质量显示
    /**
     PHImageRequestOptionsResizeModeNone,
     PHImageRequestOptionsResizeModeFast, //根据传入的size，迅速加载大小相匹配(略大于或略小于)的图像
     PHImageRequestOptionsResizeModeExact //精确的加载与传入size相匹配的图像
     */
    option.resizeMode = PHImageRequestOptionsResizeModeExact;
    option.networkAccessAllowed = YES;
    //param：targetSize 即你想要的图片尺寸，若想要原尺寸则可输入PHImageManagerMaximumSize
    [[PHCachingImageManager defaultManager] requestImageForAsset:set targetSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width * set.pixelHeight/set.pixelWidth) contentMode:PHImageContentModeAspectFit options:option resultHandler:^(UIImage * _Nullable image, NSDictionary * _Nullable info) {
 
        //解析出来的图片
        block(image,info);
    }];

}
#pragma mark 获取相册英文名对应的汉语
+ (NSString *)transformAblumTitle:(NSString *)title
{
    if ([title isEqualToString:@"Slo-mo"]) {
        return @"慢动作";
    } else if ([title isEqualToString:@"Recently Added"]) {
        return @"最近添加";
    } else if ([title isEqualToString:@"Favorites"]) {
        return @"最爱";
    } else if ([title isEqualToString:@"Recently Deleted"]) {
        return @"最近删除";
    } else if ([title isEqualToString:@"Videos"]) {
        return @"视频";
    } else if ([title isEqualToString:@"All Photos"]) {
        return @"所有照片";
    } else if ([title isEqualToString:@"Selfies"]) {
        return @"自拍";
    } else if ([title isEqualToString:@"Screenshots"]) {
        return @"屏幕快照";
    } else if ([title isEqualToString:@"Camera Roll"]) {
        return @"相机胶卷";
    }
    return nil;
}
@end

//
//  ZYImageCollectionViewController.h
//  图片选择
//
//  Created by z x h  on 2016/10/22.
//  Copyright © 2016年 ybon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
//http://blog.csdn.net/longitachi/article/details/50130957
@protocol ImagePickerControllerDelegate <NSObject>

- (void)imagePickerSelected:(NSArray *)assetUrls;

@end
@interface ZYImageCollectionViewController : UICollectionViewController
@property (nonatomic,strong)id<ImagePickerControllerDelegate>delegate;
/**可选的最大图片数量，默认是三张*/
@property (nonatomic, assign) NSInteger maxImageCount;

@property (nonatomic,strong)NSMutableArray<PHAsset *> *selectedImage;

@property (nonatomic, strong) NSMutableArray<PHAsset *> *assetArray;
@end

//
//  UIColor+AkColor.h
//  PathNote
//
//  Created by  on 12-7-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (AkColor)

+(UIColor *) colorWithHexString: (NSString *) stringToConvert;

@end

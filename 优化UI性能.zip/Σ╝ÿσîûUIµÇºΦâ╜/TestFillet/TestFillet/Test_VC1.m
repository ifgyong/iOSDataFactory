//
//  Test_VC1.m
//  TestFillet
//
//  Created by 郑冰津 on 2016/12/29.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_VC1.h"

@interface Test_VC1 ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation Test_VC1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    /*
     满屏的屎黄色,离屏渲染,在这个地方及其不适用,但是我还是要说这个方式综合考虑是最好的.
     */
    UITableView *table = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)-64) style:UITableViewStyleGrouped];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview:table];
}

#pragma mark -----------UITableViewDelegate,UITableViewDataSource-----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 600;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentifierCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IdentifierCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UILabel *Label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 44)];
        Label.tag = 991;
        Label.text = @"真爱是存在的吗";
        Label.backgroundColor = [UIColor whiteColor];
        Label.clipsToBounds=YES;
        [cell.contentView addSubview:Label];
        ///使用遮罩层,产生离屏渲染
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:Label.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(22, 22)];
        CAShapeLayer *maskLayer = [CAShapeLayer layer];
        maskLayer.backgroundColor = [UIColor whiteColor].CGColor;
        maskLayer.opaque=YES;
        maskLayer.masksToBounds=YES;
        maskLayer.frame = Label.bounds;
        maskLayer.path = maskPath.CGPath;
        Label.layer.mask = maskLayer;
        
        
        UIImageView *imageV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"lena.png"]];
        imageV.frame = CGRectMake(180, 0, 60, 44);
        [cell.contentView addSubview:imageV];
        ///使用遮罩层,产生离屏渲染
        UIBezierPath *maskPath1 = [UIBezierPath bezierPathWithRoundedRect:imageV.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(20, 20)];
        CAShapeLayer *maskLayer1 = [CAShapeLayer layer];
        maskLayer1.frame = imageV.bounds;
        maskLayer1.path = maskPath1.CGPath;
        imageV.layer.mask = maskLayer1;
//        maskLayer1.backgroundColor = [UIColor whiteColor].CGColor;//会使切圆角无效
        maskLayer1.opaque=YES;
        maskLayer1.masksToBounds=YES;
        
        
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(260, 0, 44, 44)];
        button.backgroundColor = [UIColor whiteColor];
        button.layer.cornerRadius = 22;
        button.layer.masksToBounds = YES;
        [button setImage:[UIImage imageNamed:@"lena.png"] forState:UIControlStateNormal];
        [cell.contentView addSubview:button];
        ///使用遮罩层,产生离屏渲染
        UIBezierPath *maskPath2 = [UIBezierPath bezierPathWithRoundedRect:button.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(20, 20)];
        CAShapeLayer *maskLayer2 = [CAShapeLayer layer];
        maskLayer2.frame = button.bounds;
        maskLayer2.path = maskPath2.CGPath;
        button.layer.mask = maskLayer2;
        //maskLayer1.backgroundColor = [UIColor whiteColor].CGColor;//会使切圆角无效
        maskLayer2.opaque=YES;
        maskLayer2.masksToBounds=YES;
        
        
        ///UIView的圆角产生离屏渲染,但是不会像素混合,但是没有masksToBounds就会像素混合
        UIView *view = [[UILabel alloc]initWithFrame:CGRectMake(320, 0, 60, 44)];
        view.layer.cornerRadius = 22;
        view.layer.masksToBounds = YES;
        view.backgroundColor = [UIColor purpleColor];
        [cell.contentView addSubview:view];
        ///使用遮罩层,产生离屏渲染
        UIBezierPath *maskPath3 = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(20, 20)];
        CAShapeLayer *maskLayer3 = [CAShapeLayer layer];
        maskLayer3.frame = view.bounds;
        maskLayer3.path = maskPath3.CGPath;
        view.layer.mask = maskLayer3;
        //        maskLayer1.backgroundColor = [UIColor whiteColor].CGColor;//会使切圆角无效
        maskLayer3.opaque=YES;
        maskLayer3.masksToBounds=YES;
    }
    return cell;
}

@end

//
//  main.m
//  数组或模型的数据库存储
//
//  Created by Yang on 16/3/28.
//  Copyright © 2016年 Yang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

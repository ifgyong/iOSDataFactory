//
//  ViewController.m
//  javaScriptCore_Text
//  黄保健

#import "ViewController.h"

#import <JavaScriptCore/JavaScriptCore.h>

@protocol JSObjectiveDelegate <JSExport>

//点击"拨打电话"
- (void)tel:(NSString *)string;
- (void)back;
- (void)tuichu:(NSString *)str1 a:(NSString *)str2;

@end

@interface ViewController ()<UIWebViewDelegate, JSObjectiveDelegate>
@property (nonatomic, strong) JSContext *jsContext;
@end

@implementation ViewController
{
    UIWebView *_webView1;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _webView1 = [[UIWebView alloc] initWithFrame:self.view.bounds];
    _webView1.delegate = self;
    [self.view addSubview:_webView1];
    
    [self loadExamplePage:_webView1];
}

- (void)loadExamplePage:(UIWebView*)webView {
    NSString* htmlPath = [[NSBundle mainBundle] pathForResource:@"ExampleApp" ofType:@"html"];
    NSString* appHtml = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    NSURL *baseURL = [NSURL fileURLWithPath:htmlPath];
    [webView loadHTMLString:appHtml baseURL:baseURL];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"%@", webView.request.URL.absoluteString);
    
    self.jsContext = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    self.jsContext[@"android_js_interface"] = self;//window.android_js_interface.tel
    self.jsContext.exceptionHandler = ^(JSContext *context, JSValue *exceptionValue) {
        context.exception = exceptionValue;
        NSLog(@"error information-->%@", exceptionValue);
    };
    
}

- (void)tel:(NSString *)string
{
    //拨打电话
//    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",string];
//    UIWebView * callWebview = [[UIWebView alloc] init];
//    [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
//    [self.view addSubview:callWebview];
    NSString *js = [NSString stringWithFormat:@"alert('%@')", @"1234567898765432"];
    [_webView1 stringByEvaluatingJavaScriptFromString:js];
    
    
}
- (void)back
{
    NSLog(@"================\nback\n==================");
}
- (void)tuichu:(NSString *)str1 a:(NSString *)str2
{
    NSLog(@"\n--->%@<-->%@<---\n", str1, str2);
}
@end

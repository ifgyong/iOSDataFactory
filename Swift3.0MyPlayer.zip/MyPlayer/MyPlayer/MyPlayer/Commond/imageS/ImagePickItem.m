//
//  ImagePickItem.m
//  图片选取Demo
//
//  Created by Mac on 15-11-2.
//  Copyright (c) 2015年 Mac. All rights reserved.
//

#import "ImagePickItem.h"



@implementation ImagePickItem

{
    CGPoint starPoint;
    
}


- (id)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        self.userInteractionEnabled = YES;
        [self creatDeleteButton];
        
    }
    
    return self;
}
//删除自身
- (void)creatDeleteButton{
    _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    _deleteButton.frame = CGRectMake(self.frame.size.width-20, 0, 20, 20);
    [_deleteButton setImage:[UIImage imageNamed:@"button_icon_close"] forState:UIControlStateNormal];

    [self addSubview:_deleteButton];
}

- (void)setIndex:(int)index{
    
    _index = index;
    _deleteButton.tag = kDeleteButtonTagBass + _index;
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.nextResponder touchesBegan:touches withEvent:event];
    
    UITouch *touch = [[UITouch alloc] init];
    touch = [touches anyObject];
    
    CGPoint p1 = [touch locationInView:self.superview];
    starPoint = p1;
    [UIView animateWithDuration:.35 animations:^{
        
        self.alpha = .8;
        self.transform = CGAffineTransformMakeScale(1.1, 1.1);
        
        //移动到父视图上面
        [self.superview bringSubviewToFront:self];
        
    }];
    
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.nextResponder touchesMoved:touches withEvent:event];
    
    UITouch *touch = [[UITouch alloc] init];
    touch = [touches anyObject];
    
    CGPoint p1 = [touch locationInView:self.superview];
    //获取移动得距离
    CGFloat x = p1.x - starPoint.x;
    CGFloat y = p1.y - starPoint.y;
    
    self.transform = CGAffineTransformMakeTranslation(x, y);
    
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.nextResponder touchesEnded:touches withEvent:event];
    
    [UIView animateWithDuration:.35 animations:^{
        
        self.alpha = 1;
        self.transform = CGAffineTransformIdentity;
        
       self.frame = [self getItemFrameForIndex:self.index];

        
    }];
    
    
}

- (CGRect)getItemFrameForIndex:(int)index {
    
    CGFloat x = index%3 *kImageWidth + index%3 *kSpace;
    CGFloat y = index/3 *kImageHight + index/3 *kSpace;
    
    CGRect frame = CGRectMake(x, y, kImageWidth, kImageHight);
    
    
    return frame;
}


@end



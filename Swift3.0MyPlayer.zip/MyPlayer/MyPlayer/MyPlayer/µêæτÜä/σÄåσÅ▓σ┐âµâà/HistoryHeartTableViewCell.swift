//
//  HistoryHeartTableViewCell.swift
//  MyPlayer
//
//  Created by ybon on 2016/10/31.
//  Copyright © 2016年 zxh. All rights reserved.
//

import UIKit

class HistoryHeartTableViewCell: UITableViewCell {

    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var publisherLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var delBtn: UIButton!
    var objectId:String?;
    //闭包定义为属性的格式
    var delFuncation :  (()->Void)?;
    override func awakeFromNib() {
        super.awakeFromNib()
        delBtn.layer.cornerRadius = 5;
        delBtn.layer.masksToBounds = true;
        delBtn.layer.borderWidth = 1;
        delBtn.layer.borderColor = UIColor.lightGray.cgColor;
    }
    
    
    
    @IBAction func delBtnAction(_ sender: UIButton) {
        let gamescore:BmobObject = BmobObject(outDataWithClassName: "HeartList", objectId: objectId)
        gamescore.deleteInBackground { (isSuccessful, error) in
            if self.delFuncation != nil{
                self.delFuncation!();
                
            }
            
        }
    }
    
}
